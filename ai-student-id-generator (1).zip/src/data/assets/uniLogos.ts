// Generated — bundled university logos (Wikimedia Commons), WebP, stored as text so they survive resets.
import m0 from "./uniLogos-0";

export const UNI_LOGOS: Record<string, string> = { ...m0 };
