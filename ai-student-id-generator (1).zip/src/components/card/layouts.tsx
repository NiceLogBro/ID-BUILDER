import type { ReactElement } from "react";
import type { CardModel } from "./model";
import type { LayoutId } from "../../lib/styles";
import { fitSize, textWidth } from "../../lib/text";
import {
  Barcode,
  DISPLAY,
  Expiry,
  IdPlate,
  InlineExpiry,
  InstitutionText,
  Photo,
  QrTile,
  RolePill,
  Slot,
  TextBlock,
  Tile,
  UI,
  Watermark,
  fitInstitution,
  layoutText,
  pillWidth,
  tileWidth,
} from "./parts";

type LP = { m: CardModel };

/* -------------------------------------------------------------------------- */
/*  1 · CLASSIC — dark header, centered round photo, white ID plate            */
/* -------------------------------------------------------------------------- */
function Classic({ m }: LP) {
  const { W, H, portrait } = m;
  const p = m.style.palette;
  const pw = pillWidth(m.roleLabel);
  const hy = portrait ? 28 : 24;
  const tw = tileWidth(m, 30);
  const t = portrait
    ? layoutText(m, { y1: 262, y2: 248, maxW: 302, titleGap: 30 })
    : layoutText(m, { y1: 140, y2: 126, maxW: 350, titleGap: 34 });
  const av = portrait ? { cx: W / 2, cy: 154, r: 54 } : { cx: 82, cy: 158, r: 48 };
  const tx = portrait ? W / 2 : 152;

  return (
    <g>
      <Watermark
        m={m}
        k="wm"
        x={portrait ? W - 112 : W - 100}
        y={portrait ? 66 : 62}
        s={portrait ? 96 : 84}
      />
      <rect width={W} height={6} fill={p.accent} />
      <Slot m={m} />
      <Tile m={m} k="tile" x={18} y={hy} s={30} />
      <InstitutionText text={m.institution} x={28 + tw} yc={hy + 15} maxW={W - 18 - pw - (28 + tw) - 12} color={p.text} />
      <RolePill m={m} x={W - 18} y={hy + 4} bg={p.accentSoft} color={p.accentText} />

      <Photo
        m={m}
        k="av"
        x={av.cx - av.r}
        y={av.cy - av.r}
        w={av.r * 2}
        h={av.r * 2}
        r={av.r}
        stroke={p.accent}
        strokeW={5}
      />

      <TextBlock
        m={m}
        t={t}
        x={tx}
        anchor={portrait ? "middle" : "start"}
        nameColor={p.text}
        titleColor={p.text}
        deptColor={p.subtext}
      />
      <rect x={portrait ? W / 2 - 22 : 152} y={t.bottom + 14} width={44} height={3} rx={1.5} fill={p.accent} />

      <IdPlate
        m={m}
        x={14}
        y={portrait ? H - 150 : H - 92}
        w={W - 28}
        h={portrait ? 118 : 78}
        tall={portrait}
        showExp
      />
    </g>
  );
}

/* -------------------------------------------------------------------------- */
/*  2 · BANNER — colored swoosh header, rounded photo overlapping the edge     */
/* -------------------------------------------------------------------------- */
function Banner({ m }: LP) {
  const { W, H, portrait } = m;
  const p = m.style.palette;
  const pw = pillWidth(m.roleLabel);
  const bh = portrait ? 176 : 84;
  const dip = portrait ? 40 : 28;
  const path = `M0 0H${W}V${bh}Q${W / 2} ${bh + dip} 0 ${bh}Z`;
  const ty = portrait ? 22 : 20;
  const tw = tileWidth(m, 34);
  const ph = portrait ? { x: 24, y: 120, s: 120 } : { x: 24, y: 68, s: 124 };
  const t = portrait
    ? layoutText(m, { y1: 292, y2: 278, maxW: W - 48, titleGap: 28 })
    : layoutText(m, { y1: 138, y2: 124, maxW: W - 172 - 24, titleGap: 28 });
  const tx = portrait ? 24 : 172;

  return (
    <g>
      <clipPath id={`${m.uid}-ban`}>
        <path d={path} />
      </clipPath>
      <path d={path} fill={`url(#${m.uid}-ac)`} />
      <g clipPath={`url(#${m.uid}-ban)`}>
        <circle cx={W - 40} cy={portrait ? 50 : 30} r={portrait ? 100 : 80} fill={p.onAccent} opacity={0.08} />
        <circle cx={W - 130} cy={portrait ? 160 : 90} r={portrait ? 64 : 50} fill={p.onAccent} opacity={0.07} />
        {portrait && <Watermark m={m} k="wm" x={W - 124} y={66} s={100} opacity={0.2} />}
      </g>
      {/* landscape: keep the crest out of the header so it never collides with the role pill */}
      {!portrait && <Watermark m={m} k="wm2" x={W - 24 - 120} y={104} s={120} opacity={0.1} />}
      <Slot m={m} y={9} />

      <Tile m={m} k="tile" x={18} y={ty} s={34} onAccent />
      <InstitutionText text={m.institution} x={28 + tw} yc={ty + 17} maxW={W - 18 - pw - (28 + tw) - 12} color={p.onAccent} />
      <RolePill m={m} x={W - 18} y={ty + 6} bg={p.onAccent} bgOpacity={0.2} color={p.onAccent} />

      <Photo m={m} k="ph" x={ph.x} y={ph.y} w={ph.s} h={ph.s} r={30} stroke={p.bg} strokeW={6} />

      {portrait && (
        <g>
          <Expiry
            m={m}
            cx={160}
            ly={212}
            vy={234}
            label="VALID THRU"
            anchor="start"
            vsize={15}
            labelColor={p.subtext}
            valueColor={p.text}
          />
          <rect x={160} y={244} width={36} height={3} rx={1.5} fill={p.accent} />
        </g>
      )}

      <TextBlock
        m={m}
        t={t}
        x={tx}
        anchor="start"
        nameColor={p.text}
        titleColor={p.text}
        deptColor={p.accentText}
        titleWeight={600}
      />

      <IdPlate
        m={m}
        x={14}
        y={portrait ? H - 122 : H - 92}
        w={W - 28}
        h={portrait ? 108 : 78}
        tall={portrait}
        showExp={!portrait}
      />
    </g>
  );
}

/* -------------------------------------------------------------------------- */
/*  3 · MODERN — full-bleed photo block, big left-aligned type, bare ID row    */
/* -------------------------------------------------------------------------- */
function Modern({ m }: LP) {
  const { W, H, portrait } = m;
  const p = m.style.palette;
  const pw = pillWidth(m.roleLabel);
  const idText = m.empId || "——————";

  if (portrait) {
    const chipX = 26;
    const chipY = 26;
    const tw = tileWidth(m, 30);
    const textX = chipX + 4 + tw + 8;
    const maxTextW = W - 26 - pw - 10 - 12 - textX;
    const fit = fitInstitution(m.institution, maxTextW, 12);
    const lw = Math.max(...fit.lines.map((l) => textWidth(l, fit.size, 700, "ui", 0.3)));
    const chipW = textX - chipX + lw + 14;
    const t = layoutText(m, { y1: 312, y2: 298, maxW: W - 42 - 26, titleGap: 28, maxSize: 28 });
    const T = H - 112;
    const qrS = 72;
    const rightLimit = m.showQr ? W - 26 - qrS - 16 : W - 26;
    const vs = fitSize(idText, rightLimit - 26, 24, 14, 700, "display", 1);

    return (
      <g>
        <Photo m={m} k="ph" x={14} y={14} w={W - 28} h={250} r={22} />
        <rect x={chipX} y={chipY} width={chipW} height={38} rx={19} fill={p.bg} fillOpacity={0.82} />
        <Tile m={m} k="tile" x={chipX + 4} y={chipY + 4} s={30} />
        <InstitutionText text={m.institution} x={textX} yc={chipY + 19} maxW={maxTextW} color={p.text} size={12} />
        <RolePill m={m} x={W - 26} y={chipY + 8} bg={p.accent} color={p.onAccent} />

        <rect
          x={26}
          y={t.baselines[0] - t.fit.size * 0.8}
          width={3.5}
          height={t.bottom + 4 - (t.baselines[0] - t.fit.size * 0.8)}
          rx={1.75}
          fill={p.accent}
        />
        <TextBlock
          m={m}
          t={t}
          x={42}
          anchor="start"
          nameColor={p.text}
          titleColor={p.accentText}
          deptColor={p.subtext}
          titleWeight={600}
        />

        <text x={26} y={T + 10} fontFamily={UI} fontWeight={800} fontSize={9} letterSpacing={1.4} fill={p.subtext}>
          {m.idLabel}
        </text>
        <text x={26} y={T + 40} fontFamily={DISPLAY} fontWeight={700} fontSize={vs} letterSpacing={1} fill={p.text}>
          {idText}
        </text>
        <InlineExpiry m={m} x={26} y={T + 64} labelColor={p.subtext} valueColor={p.text} />
        {m.showBarcode && <Barcode x={26} y={T + 76} w={rightLimit - 26} h={22} seed={m.empId} color={p.text} />}
        {m.showQr && <QrTile m={m} x={W - 26 - qrS} y={T + 2} s={qrS} />}
      </g>
    );
  }

  // landscape
  const x0 = 232;
  const tw = tileWidth(m, 30);
  const t = layoutText(m, { y1: 150, y2: 136, maxW: W - 250 - 20, titleGap: 28, maxSize: 28 });
  const T = H - 104;
  const vs = fitSize(idText, 118, 22, 13, 700, "display", 1);
  const barX = 352;
  return (
    <g>
      <Photo m={m} k="ph" x={14} y={14} w={196} h={H - 28} r={22} />
      <RolePill m={m} x={28} y={28} align="start" bg={p.accent} color={p.onAccent} />

      <Tile m={m} k="tile" x={x0} y={24} s={30} />
      <InstitutionText text={m.institution} x={x0 + tw + 8} yc={39} maxW={W - 18 - (x0 + tw + 8)} color={p.text} />

      <rect
        x={x0}
        y={t.baselines[0] - t.fit.size * 0.8}
        width={3.5}
        height={t.bottom + 4 - (t.baselines[0] - t.fit.size * 0.8)}
        rx={1.75}
        fill={p.accent}
      />
      <TextBlock
        m={m}
        t={t}
        x={250}
        anchor="start"
        nameColor={p.text}
        titleColor={p.accentText}
        deptColor={p.subtext}
        titleWeight={600}
      />

      <text x={x0} y={T + 12} fontFamily={UI} fontWeight={800} fontSize={9} letterSpacing={1.4} fill={p.subtext}>
        {m.idLabel}
      </text>
      <text x={x0} y={T + 40} fontFamily={DISPLAY} fontWeight={700} fontSize={vs} letterSpacing={1} fill={p.text}>
        {idText}
      </text>
      <InlineExpiry m={m} x={x0} y={T + 66} labelColor={p.subtext} valueColor={p.text} />
      {m.showBarcode && (
        <Barcode x={barX} y={T + 16} w={m.showQr ? 88 : W - 18 - barX} h={44} seed={m.empId} color={p.text} />
      )}
      {m.showQr && <QrTile m={m} x={W - 18 - 64} y={T + 12} s={64} />}
    </g>
  );
}

/* -------------------------------------------------------------------------- */
/*  4 · CAMPUS — vintage striped header, framed photo, big crest watermark     */
/* -------------------------------------------------------------------------- */
function Campus({ m }: LP) {
  const { W, portrait } = m;
  const p = m.style.palette;
  const pw = pillWidth(m.roleLabel);
  const idText = m.empId || "——————";

  if (portrait) {
    const t = layoutText(m, {
      y1: 336,
      y2: 324,
      maxW: 300,
      titleGap: 24,
      deptGap: 18,
      maxSize: 24,
      minSingle: 18,
      minSize: 14,
    });
    const qrOn = m.showQr;
    const tw = tileWidth(m, 46);
    const tx = qrOn ? 106 : 30;
    const vs = fitSize(idText, W - 30 - tx, 22, 14, 700, "display", 1);
    return (
      <g>
        <Watermark m={m} k="wm" x={W / 2 - 120} y={170} s={240} opacity={0.07} />
        <rect width={W} height={132} fill={`url(#${m.uid}-ac)`} />
        <rect y={132} width={W} height={6} fill={p.accent2} />
        <rect y={142} width={W} height={3} fill={p.accent} />
        <Slot m={m} y={9} />
        <Tile m={m} k="tile" x={20} y={34} s={46} onAccent />
        <InstitutionText
          text={m.institution.toUpperCase()}
          x={32 + tw}
          yc={58}
          maxW={W - (32 + tw) - 20}
          color={p.onAccent}
          size={14}
          weight={800}
          ls={0.8}
        />
        <RolePill m={m} x={32 + tw} y={92} align="start" bg={p.onAccent} bgOpacity={0.2} color={p.onAccent} />

        <rect x={W / 2 - 56 + 5} y={164} width={112} height={136} rx={12} fill={p.text} opacity={0.12} />
        <Photo m={m} k="ph" x={W / 2 - 56} y={158} w={112} h={136} r={12} stroke={p.accent} strokeW={4} />

        <TextBlock
          m={m}
          t={t}
          x={W / 2}
          anchor="middle"
          nameColor={p.text}
          titleColor={p.accentText}
          deptColor={p.subtext}
          titleWeight={700}
        />

        <rect x={30} y={404} width={W - 60} height={1} fill={p.subtext} opacity={0.35} />
        {qrOn && <QrTile m={m} x={30} y={416} s={60} />}
        <text x={tx} y={430} fontFamily={UI} fontWeight={800} fontSize={9} letterSpacing={1.4} fill={p.subtext}>
          {m.idLabel}
        </text>
        <text x={tx} y={454} fontFamily={DISPLAY} fontWeight={700} fontSize={vs} letterSpacing={1} fill={p.text}>
          {idText}
        </text>
        <InlineExpiry m={m} x={tx} y={474} labelColor={p.subtext} valueColor={p.text} />
        {m.showBarcode && <Barcode x={30} y={490} w={W - 60} h={24} seed={m.empId} color={p.text} />}
      </g>
    );
  }

  // landscape
  const t = layoutText(m, {
    y1: 152,
    y2: 138,
    maxW: W - 164 - 24,
    titleGap: 26,
    deptGap: 20,
    maxSize: 26,
    minSingle: 19,
  });
  const vs = fitSize(idText, 190, 20, 13, 700, "display", 1);
  const tw = tileWidth(m, 40);
  return (
    <g>
      <Watermark m={m} k="wm" x={W - 214} y={104} s={190} opacity={0.07} />
      <rect width={W} height={86} fill={`url(#${m.uid}-ac)`} />
      <rect y={86} width={W} height={5} fill={p.accent2} />
      <rect y={95} width={W} height={2} fill={p.accent} />
      <Slot m={m} y={8} />
      <Tile m={m} k="tile" x={18} y={23} s={40} onAccent />
      <InstitutionText
        text={m.institution.toUpperCase()}
        x={30 + tw}
        yc={43}
        maxW={W - (30 + tw) - 18 - pw - 14}
        color={p.onAccent}
        size={14}
        weight={800}
        ls={0.8}
      />
      <RolePill m={m} x={W - 18} y={32} bg={p.onAccent} bgOpacity={0.2} color={p.onAccent} />

      <rect x={26 + 5} y={118} width={112} height={140} rx={12} fill={p.text} opacity={0.12} />
      <Photo m={m} k="ph" x={26} y={112} w={112} h={140} r={12} stroke={p.accent} strokeW={4} />
      <Expiry m={m} cx={82} ly={278} vy={296} labelColor={p.subtext} valueColor={p.text} />

      <TextBlock
        m={m}
        t={t}
        x={164}
        anchor="start"
        nameColor={p.text}
        titleColor={p.accentText}
        deptColor={p.subtext}
        titleWeight={700}
      />

      <rect x={164} y={246} width={W - 164 - 24} height={1} fill={p.subtext} opacity={0.35} />
      <text x={164} y={266} fontFamily={UI} fontWeight={800} fontSize={9} letterSpacing={1.4} fill={p.subtext}>
        {m.idLabel}
      </text>
      <text x={164} y={290} fontFamily={DISPLAY} fontWeight={700} fontSize={vs} letterSpacing={1} fill={p.text}>
        {idText}
      </text>
      {m.showBarcode && <Barcode x={164} y={300} w={m.showQr ? 190 : W - 164 - 24} h={24} seed={m.empId} color={p.text} />}
      {m.showQr && <QrTile m={m} x={W - 24 - 60} y={258} s={60} />}
    </g>
  );
}

export const LAYOUTS: Record<LayoutId, (props: LP) => ReactElement> = {
  classic: Classic,
  banner: Banner,
  modern: Modern,
  campus: Campus,
};
