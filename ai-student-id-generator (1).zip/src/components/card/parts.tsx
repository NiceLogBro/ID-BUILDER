import type { CardModel } from "./model";
import { barcodeBars } from "../../lib/badge";
import { fitLines, fitSize, textWidth, type Fit } from "../../lib/text";

export const UI = "Manrope, 'Helvetica Neue', Arial, sans-serif";
export const DISPLAY = "'Space Grotesk', Manrope, Arial, sans-serif";

/* ------------------------------ logo / crest ------------------------------ */

/** Real logos are often wide wordmarks, so their tile widens (up to 2.3×) to keep them legible. */
export function tileWidth(m: CardModel, s: number): number {
  if (m.crestUrl && m.crestFit === "contain") return Math.round(s * Math.min(2.3, Math.max(1, m.crestAspect)));
  return s;
}

export function Tile({
  m,
  k,
  x,
  y,
  s,
  onAccent = false,
}: {
  m: CardModel;
  k: string;
  x: number;
  y: number;
  s: number;
  onAccent?: boolean;
}) {
  const p = m.style.palette;
  const id = `${m.uid}-${k}`;
  const rx = s * 0.27;
  if (m.crestUrl && m.crestFit === "contain") {
    const w = tileWidth(m, s);
    const pad = Math.max(3, s * 0.12);
    return (
      <g>
        <rect x={x} y={y} width={w} height={s} rx={rx} fill={m.crestDark ? "#14171c" : "#ffffff"} />
        <image
          href={m.crestUrl}
          x={x + pad}
          y={y + pad}
          width={w - pad * 2}
          height={s - pad * 2}
          preserveAspectRatio="xMidYMid meet"
        />
      </g>
    );
  }
  if (m.crestUrl) {
    return (
      <g>
        <clipPath id={id}>
          <rect x={x} y={y} width={s} height={s} rx={rx} />
        </clipPath>
        <rect x={x} y={y} width={s} height={s} rx={rx} fill="#ffffff" />
        <image
          href={m.crestUrl}
          x={x}
          y={y}
          width={s}
          height={s}
          preserveAspectRatio="xMidYMid slice"
          clipPath={`url(#${id})`}
        />
      </g>
    );
  }
  const letter = (Array.from(m.institution.trim())[0] || "B").toUpperCase();
  return (
    <g>
      <rect x={x} y={y} width={s} height={s} rx={rx} fill={onAccent ? p.onAccent : p.accent} />
      <text
        x={x + s / 2}
        y={y + s * 0.67}
        textAnchor="middle"
        fontFamily={DISPLAY}
        fontWeight={700}
        fontSize={s * 0.5}
        fill={onAccent ? p.accent : p.onAccent}
      >
        {letter}
      </text>
    </g>
  );
}

export function Watermark({
  m,
  k,
  x,
  y,
  s,
  opacity = 0.13,
}: {
  m: CardModel;
  k: string;
  x: number;
  y: number;
  s: number;
  opacity?: number;
}) {
  if (!m.crestUrl) return null;
  // A wide wordmark as a ghosted watermark just smears across the photo and text — skip it.
  if (m.crestFit === "contain" && m.crestAspect > 1.9) return null;
  if (m.crestFit === "contain") {
    return (
      <g opacity={opacity}>
        <image href={m.crestUrl} x={x} y={y} width={s} height={s} preserveAspectRatio="xMidYMid meet" />
      </g>
    );
  }
  const id = `${m.uid}-${k}`;
  return (
    <g opacity={opacity}>
      <clipPath id={id}>
        <circle cx={x + s / 2} cy={y + s / 2} r={s / 2} />
      </clipPath>
      <image
        href={m.crestUrl}
        x={x}
        y={y}
        width={s}
        height={s}
        preserveAspectRatio="xMidYMid slice"
        clipPath={`url(#${id})`}
      />
    </g>
  );
}

export function Slot({ m, y = 16 }: { m: CardModel; y?: number }) {
  return <rect x={m.W / 2 - 26} y={y} width={52} height={10} rx={5} fill={m.style.palette.slot} />;
}

/* --------------------------------- text ----------------------------------- */

export function pillWidth(label: string) {
  return textWidth(label.toUpperCase(), 10, 800, "ui", 1.2) + 26;
}

export function RolePill({
  m,
  x,
  y,
  h = 22,
  align = "end",
  bg,
  bgOpacity = 1,
  color,
}: {
  m: CardModel;
  x: number;
  y: number;
  h?: number;
  align?: "start" | "end";
  bg: string;
  bgOpacity?: number;
  color: string;
}) {
  const label = m.roleLabel.toUpperCase();
  const w = pillWidth(m.roleLabel);
  const x0 = align === "end" ? x - w : x;
  return (
    <g>
      <rect x={x0} y={y} width={w} height={h} rx={h / 2} fill={bg} fillOpacity={bgOpacity} />
      <text
        x={x0 + w / 2 + 0.6}
        y={y + h / 2 + 3.6}
        textAnchor="middle"
        fontFamily={UI}
        fontWeight={800}
        fontSize={10}
        letterSpacing={1.2}
        fill={color}
      >
        {label}
      </text>
    </g>
  );
}

export function fitInstitution(text: string, maxW: number, size = 13, weight = 700, ls = 0.3): Fit {
  return fitLines(text || "Your organization", {
    maxWidth: maxW,
    maxLines: 2,
    maxSize: size,
    minSize: Math.max(9, size - 3.5),
    weight,
    kind: "ui",
    ls,
  });
}

export function InstitutionText({
  text,
  x,
  yc,
  maxW,
  color,
  size = 13,
  weight = 700,
  ls = 0.3,
}: {
  text: string;
  x: number;
  yc: number;
  maxW: number;
  color: string;
  size?: number;
  weight?: number;
  ls?: number;
}) {
  const f = fitInstitution(text, maxW, size, weight, ls);
  const lh = f.size * 1.18;
  const first = yc - ((f.lines.length - 1) * lh) / 2 + f.size * 0.35;
  return (
    <g fontFamily={UI} fontWeight={weight} fontSize={f.size} letterSpacing={ls} fill={color}>
      {f.lines.map((l, i) => (
        <text key={i} x={x} y={first + i * lh}>
          {l}
        </text>
      ))}
    </g>
  );
}

export interface TextLayout {
  fit: Fit;
  empty: boolean;
  baselines: number[];
  titleY: number;
  deptY: number;
  bottom: number;
  titleSize: number;
  deptSize: number;
}

export function layoutText(
  m: CardModel,
  o: {
    /** baseline of the first name line when the name fits on one line */
    y1: number;
    /** baseline of the first name line when it wraps onto two */
    y2: number;
    maxW: number;
    titleGap: number;
    deptGap?: number;
    maxSize?: number;
    minSingle?: number;
    minSize?: number;
    lineGap?: number;
  }
): TextLayout {
  const empty = !m.name.trim();
  const fit: Fit = empty
    ? { lines: ["Your name"], size: 24 }
    : fitLines(m.name.trim(), {
        maxWidth: o.maxW,
        maxLines: 2,
        maxSize: o.maxSize ?? 26,
        minSize: o.minSize ?? 15,
        minSingle: o.minSingle ?? 20,
        weight: 700,
        kind: "display",
      });
  const first = fit.lines.length > 1 ? o.y2 : o.y1;
  const gap = o.lineGap ?? 6;
  const baselines = fit.lines.map((_, i) => first + i * (fit.size + gap));
  const last = baselines[baselines.length - 1];
  const title = m.title.trim();
  const dept = m.department.trim();
  const titleY = last + o.titleGap;
  const deptY = title ? titleY + (o.deptGap ?? 22) : titleY;
  return {
    fit,
    empty,
    baselines,
    titleY,
    deptY,
    bottom: dept ? deptY : title ? titleY : last,
    titleSize: fitSize(title, o.maxW, 14, 10, 600, "ui"),
    deptSize: fitSize(dept.toUpperCase(), o.maxW, 11, 8, 700, "ui", 1.6),
  };
}

export function TextBlock({
  m,
  t,
  x,
  anchor,
  nameColor,
  titleColor,
  deptColor,
  titleWeight = 500,
}: {
  m: CardModel;
  t: TextLayout;
  x: number;
  anchor: "start" | "middle";
  nameColor: string;
  titleColor: string;
  deptColor: string;
  titleWeight?: number;
}) {
  const title = m.title.trim();
  const dept = m.department.trim();
  return (
    <g textAnchor={anchor}>
      {t.fit.lines.map((l, i) => (
        <text
          key={i}
          x={x}
          y={t.baselines[i]}
          fontFamily={DISPLAY}
          fontWeight={700}
          fontSize={t.fit.size}
          fill={t.empty ? deptColor : nameColor}
          opacity={t.empty ? 0.7 : 1}
        >
          {l}
        </text>
      ))}
      {title && (
        <text x={x} y={t.titleY} fontFamily={UI} fontWeight={titleWeight} fontSize={t.titleSize} fill={titleColor}>
          {title}
        </text>
      )}
      {dept && (
        <text
          x={x}
          y={t.deptY}
          fontFamily={UI}
          fontWeight={700}
          fontSize={t.deptSize}
          letterSpacing={1.6}
          fill={deptColor}
        >
          {dept.toUpperCase()}
        </text>
      )}
    </g>
  );
}

/* --------------------------------- photo ---------------------------------- */

export function Photo({
  m,
  k,
  x,
  y,
  w,
  h,
  r,
  stroke,
  strokeW = 0,
}: {
  m: CardModel;
  k: string;
  x: number;
  y: number;
  w: number;
  h: number;
  r: number;
  stroke?: string;
  strokeW?: number;
}) {
  const p = m.style.palette;
  const id = `${m.uid}-${k}`;
  const size = Math.min(w, h) * 0.36;
  return (
    <g>
      <clipPath id={id}>
        <rect x={x} y={y} width={w} height={h} rx={r} />
      </clipPath>
      <rect x={x} y={y} width={w} height={h} rx={r} fill={p.accentSoft} />
      {m.imageUrl ? (
        <image
          href={m.imageUrl}
          x={x}
          y={y}
          width={w}
          height={h}
          preserveAspectRatio="xMidYMin slice"
          clipPath={`url(#${id})`}
        />
      ) : (
        <text
          x={x + w / 2}
          y={y + h / 2 + size * 0.34}
          textAnchor="middle"
          fontFamily={DISPLAY}
          fontWeight={700}
          fontSize={size}
          fill={p.accentText}
        >
          {m.initials}
        </text>
      )}
      {strokeW > 0 && (
        <rect
          x={x + strokeW / 2}
          y={y + strokeW / 2}
          width={w - strokeW}
          height={h - strokeW}
          rx={Math.max(0, r - strokeW / 2)}
          fill="none"
          stroke={stroke}
          strokeWidth={strokeW}
        />
      )}
    </g>
  );
}

/* ------------------------------ ID furniture ------------------------------ */

export function Barcode({
  x,
  y,
  w,
  h,
  seed,
  color,
}: {
  x: number;
  y: number;
  w: number;
  h: number;
  seed: string;
  color: string;
}) {
  const widths = barcodeBars(seed || "x", 46);
  const gaps = widths.map((_, i) => (i % 2 === 0 ? 2 : 1));
  const total = widths.reduce((a, b, i) => a + b + gaps[i], 0) - gaps[gaps.length - 1];
  const sc = w / total;
  let cx = x;
  return (
    <g fill={color}>
      {widths.map((b, i) => {
        const bw = b * sc;
        const el = <rect key={i} x={cx} y={y} width={Math.max(bw, 0.8)} height={h} />;
        cx += bw + gaps[i] * sc;
        return el;
      })}
    </g>
  );
}

export function QrTile({ m, x, y, s }: { m: CardModel; x: number; y: number; s: number }) {
  return (
    <g>
      <rect x={x} y={y} width={s} height={s} rx={7} fill="#ffffff" />
      {m.qrUrl && <image href={m.qrUrl} x={x + 5} y={y + 5} width={s - 10} height={s - 10} />}
    </g>
  );
}

export function Expiry({
  m,
  cx,
  ly,
  vy,
  labelColor,
  valueColor,
  anchor = "middle",
  vsize = 12,
  label = "EXPIRES",
}: {
  m: CardModel;
  cx: number;
  ly: number;
  vy: number;
  labelColor: string;
  valueColor: string;
  anchor?: "start" | "middle";
  vsize?: number;
  label?: string;
}) {
  return (
    <g textAnchor={anchor}>
      <text x={cx} y={ly} fontFamily={UI} fontWeight={800} fontSize={8} letterSpacing={1.2} fill={labelColor}>
        {label}
      </text>
      <text x={cx} y={vy} fontFamily={UI} fontWeight={700} fontSize={vsize} fill={valueColor}>
        {m.expires}
      </text>
    </g>
  );
}

/** "EXPIRES  JUN 2027" on a single line */
export function InlineExpiry({
  m,
  x,
  y,
  labelColor,
  valueColor,
}: {
  m: CardModel;
  x: number;
  y: number;
  labelColor: string;
  valueColor: string;
}) {
  const lw = textWidth("EXPIRES", 8, 800, "ui", 1.2);
  return (
    <g>
      <text x={x} y={y} fontFamily={UI} fontWeight={800} fontSize={8} letterSpacing={1.2} fill={labelColor}>
        EXPIRES
      </text>
      <text x={x + lw + 8} y={y} fontFamily={UI} fontWeight={700} fontSize={12} fill={valueColor}>
        {m.expires}
      </text>
    </g>
  );
}

/** The filled ID "label plate" with the ID number, barcode, QR and (optionally) the expiry date. */
export function IdPlate({
  m,
  x,
  y: y0,
  w,
  h: h0,
  tall,
  showExp,
}: {
  m: CardModel;
  x: number;
  y: number;
  w: number;
  h: number;
  tall: boolean;
  showExp: boolean;
}) {
  const p = m.style.palette;
  // With no QR and no barcode there's little to show — shrink the plate (anchored to the bottom)
  // instead of leaving a big empty box.
  const compact = tall && !m.showBarcode && !m.showQr;
  const h = compact ? 76 : h0;
  const y = compact ? y0 + h0 - h : y0;
  const pad = 16;
  const lx = x + pad;
  const idText = m.empId || "——————";
  const label = (
    <text
      x={lx}
      y={y + (tall ? 26 : 18)}
      fontFamily={UI}
      fontWeight={800}
      fontSize={9}
      letterSpacing={1.4}
      fill={p.plateSub}
    >
      {m.idLabel}
    </text>
  );

  if (tall) {
    const qrS = 58;
    const qr = m.showQr ? { x: x + w - pad - qrS, y: y + (showExp ? 14 : (h - qrS) / 2), s: qrS } : null;
    const rightEdge = qr ? qr.x - 12 : x + w - pad;
    const vs = fitSize(idText, rightEdge - lx, 20, 12, 700, "display", 1);
    return (
      <g>
        <rect x={x} y={y} width={w} height={h} rx={14} fill={p.plate} />
        {label}
        <text x={lx} y={y + 50} fontFamily={DISPLAY} fontWeight={700} fontSize={vs} letterSpacing={1} fill={p.plateText}>
          {idText}
        </text>
        {m.showBarcode && (
          <Barcode x={lx} y={y + 64} w={(qr ? qr.x - 14 : x + w - pad) - lx} h={30} seed={m.empId} color={p.plateText} />
        )}
        {qr && <QrTile m={m} x={qr.x} y={qr.y} s={qr.s} />}
        {showExp && (
          <Expiry
            m={m}
            cx={qr ? qr.x + qr.s / 2 : x + w - pad - 40}
            ly={qr ? y + 92 : y + 30}
            vy={qr ? y + 106 : y + 48}
            labelColor={p.plateSub}
            valueColor={p.plateText}
          />
        )}
      </g>
    );
  }

  const qrS = 52;
  const qr = m.showQr ? { x: x + w - pad - qrS, y: y + 13, s: qrS } : null;
  const R0 = qr ? qr.x - 14 : x + w - pad;
  const bx = x + 170;
  const bRight = showExp ? R0 - 90 : R0;
  const vs = fitSize(idText, bx - 14 - lx, 18, 12, 700, "display", 1);
  return (
    <g>
      <rect x={x} y={y} width={w} height={h} rx={14} fill={p.plate} />
      {label}
      <text x={lx} y={y + 42} fontFamily={DISPLAY} fontWeight={700} fontSize={vs} letterSpacing={1} fill={p.plateText}>
        {idText}
      </text>
      {m.showBarcode && <Barcode x={bx} y={y + 18} w={bRight - bx} h={34} seed={m.empId} color={p.plateText} />}
      {qr && <QrTile m={m} x={qr.x} y={qr.y} s={qr.s} />}
      {showExp && (
        <Expiry m={m} cx={R0 - 40} ly={y + 30} vy={y + 50} labelColor={p.plateSub} valueColor={p.plateText} />
      )}
    </g>
  );
}
