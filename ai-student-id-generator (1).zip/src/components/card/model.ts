import type { Role } from "../../types";
import type { CardStyle } from "../../lib/styles";

export const CARD_SIZE = {
  portrait: { W: 342, H: 534 },
  landscape: { W: 534, H: 342 },
} as const;

/** Everything a card layout needs to draw itself. */
export interface CardModel {
  uid: string;
  portrait: boolean;
  W: number;
  H: number;
  style: CardStyle;
  /** display name (casing already applied) — empty string if nothing typed yet */
  name: string;
  initials: string;
  title: string;
  department: string;
  institution: string;
  crestUrl: string | null;
  /** "cover" = full-bleed square art; "contain" = a real logo drawn on a padded tile */
  crestFit: "cover" | "contain";
  /** width / height of the crest image (real logos can be wide wordmarks) */
  crestAspect: number;
  /** mostly-white logo artwork that needs a dark tile */
  crestDark: boolean;
  imageUrl: string | null;
  role: Role;
  roleLabel: string;
  idLabel: string;
  empId: string;
  /** already formatted, e.g. "JUN 2027" */
  expires: string;
  qrUrl: string;
  showQr: boolean;
  showBarcode: boolean;
}

export type CardInput = Omit<CardModel, "uid">;
