import { forwardRef, useId } from "react";
import type { CardInput, CardModel } from "./model";
import type { PatternId } from "../../lib/styles";
import { LAYOUTS } from "./layouts";

function PatternDef({ id, kind, color }: { id: string; kind: PatternId; color: string }) {
  switch (kind) {
    case "dots":
      return (
        <pattern id={id} width={16} height={16} patternUnits="userSpaceOnUse">
          <circle cx={8} cy={8} r={1} fill={color} />
        </pattern>
      );
    case "lines":
      return (
        <pattern id={id} width={14} height={14} patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
          <line x1={0} y1={0} x2={0} y2={14} stroke={color} strokeWidth={1} />
        </pattern>
      );
    case "grid":
      return (
        <pattern id={id} width={20} height={20} patternUnits="userSpaceOnUse">
          <path d="M20 0H0V20" fill="none" stroke={color} strokeWidth={1} />
        </pattern>
      );
    case "cross":
      return (
        <pattern id={id} width={22} height={22} patternUnits="userSpaceOnUse">
          <path d="M11 8v6M8 11h6" stroke={color} strokeWidth={1.2} strokeLinecap="round" />
        </pattern>
      );
    default:
      return null;
  }
}

interface Props {
  model: CardInput;
  /** display scale (1 = 342 × 534 portrait / 534 × 342 landscape) */
  scale?: number;
  className?: string;
}

/**
 * The ID card, as a single SVG. The same element powers the live preview, the style thumbnails
 * and the PNG export, so they can never drift apart.
 */
export const CardSvg = forwardRef<SVGSVGElement, Props>(function CardSvg({ model, scale = 1, className }, ref) {
  const uid = "c" + useId().replace(/[^a-zA-Z0-9]/g, "");
  const m: CardModel = { ...model, uid };
  const { W, H } = m;
  const { palette: p, pattern, radius } = m.style;
  const Layout = LAYOUTS[m.style.layout];

  return (
    <svg
      ref={ref}
      xmlns="http://www.w3.org/2000/svg"
      viewBox={`0 0 ${W} ${H}`}
      width={W * scale}
      height={H * scale}
      className={className}
      style={{ display: "block" }}
      role="img"
      aria-label={`${m.roleLabel} ID card for ${m.name || "an unnamed person"}${m.institution ? ` at ${m.institution}` : ""}`}
    >
      <defs>
        <linearGradient id={`${uid}-bg`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor={p.bg} />
          <stop offset="1" stopColor={p.bg2} />
        </linearGradient>
        <linearGradient id={`${uid}-ac`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor={p.accent} />
          <stop offset="1" stopColor={p.accent2} />
        </linearGradient>
        <clipPath id={`${uid}-card`}>
          <rect width={W} height={H} rx={radius} />
        </clipPath>
        <PatternDef id={`${uid}-pat`} kind={pattern} color={p.patternColor} />
      </defs>
      <g clipPath={`url(#${uid}-card)`}>
        <rect width={W} height={H} fill={`url(#${uid}-bg)`} />
        {pattern !== "none" && <rect width={W} height={H} fill={`url(#${uid}-pat)`} />}
        <Layout m={m} />
      </g>
    </svg>
  );
});
