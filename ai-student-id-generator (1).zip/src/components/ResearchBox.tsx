import { useEffect, useState } from "react";
import { cn } from "../utils/cn";
import { Icon } from "./Icon";
import { ResearchSteps } from "./ResearchSteps";
import { inputCls } from "./ui";
import {
  commonsPreview,
  hostOf,
  researchOrganizations,
  type OrgCandidate,
  type ResearchResult,
  type ResearchStep,
} from "../lib/research";
import { COMPANY_MAP, findCompanyByName, formatEmployees } from "../lib/companies";
import { INDUSTRY_NAME } from "../lib/industries";
import { orgInitials } from "../lib/logoStudio";

interface Props {
  name: string;
  onName: (v: string) => void;
  onUse: (c: OrgCandidate) => void;
  /** the candidate whose logo is being researched right now, with its work log */
  adopting: { qid: string; steps: ResearchStep[] } | null;
}

type Status = "idle" | "running" | "done" | "error";

function CandidateThumb({ c }: { c: OrgCandidate }) {
  const [broken, setBroken] = useState(false);
  const file = c.logoFile ?? c.smallLogoFile;
  if (file && !broken) {
    return (
      <img
        src={commonsPreview(file, 120)}
        alt=""
        loading="lazy"
        onError={() => setBroken(true)}
        className="h-10 w-10 shrink-0 rounded-lg bg-white object-contain p-1"
      />
    );
  }
  return (
    <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-ink-700 text-[11px] font-bold text-ink-200">
      {orgInitials(c.name)}
    </span>
  );
}

/**
 * Type any organization name: it's researched live (Wikidata, Wikipedia, Wikimedia Commons) for the
 * real name and official logo. Pick a match — or keep your own name and the logo studio designs a logo.
 */
export function ResearchBox({ name, onName, onUse, adopting }: Props) {
  const [status, setStatus] = useState<Status>("idle");
  const [steps, setSteps] = useState<ResearchStep[]>([]);
  const [res, setRes] = useState<ResearchResult | null>(null);
  const [expanded, setExpanded] = useState(false);
  const [nonce, setNonce] = useState(0);

  useEffect(() => {
    const q = name.trim();
    setExpanded(false);
    if (q.length < 2) {
      setStatus("idle");
      setSteps([]);
      setRes(null);
      return;
    }
    const ctrl = new AbortController();
    const log: ResearchStep[] = [];
    const push = (s: ResearchStep) => {
      const i = log.findIndex((x) => x.id === s.id);
      if (i >= 0) log[i] = s;
      else log.push(s);
      if (!ctrl.signal.aborted) setSteps([...log]);
    };
    const timer = window.setTimeout(() => {
      setStatus("running");
      setRes(null);
      setSteps([]);
      researchOrganizations(q, push, ctrl.signal)
        .then((r) => {
          if (ctrl.signal.aborted) return;
          setRes(r);
          setStatus("done");
        })
        .catch(() => {
          if (!ctrl.signal.aborted) setStatus("error");
        });
    }, 650);
    return () => {
      window.clearTimeout(timer);
      ctrl.abort();
    };
  }, [name, nonce]);

  const q = name.trim();
  const list = res?.candidates ?? [];
  const shown = expanded ? list : list.slice(0, 3);

  return (
    <div className="space-y-2.5">
      <label className="block">
        <span className="mb-1.5 flex items-baseline justify-between">
          <span className="text-xs font-semibold text-ink-300">Organization name</span>
          <span className="text-[10px] tabular-nums text-ink-500">{name.length}/40</span>
        </span>
        <span className="relative block">
          <Icon name="search" className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-500" />
          <input
            className={cn(inputCls, "pl-9")}
            value={name}
            maxLength={40}
            placeholder="Type any company — e.g. Patagonia"
            aria-label="Organization name (researched automatically)"
            onChange={(e) => onName(e.target.value)}
          />
        </span>
      </label>

      <div className="space-y-2.5 rounded-lg border border-ink-700 bg-ink-850 p-3">
        <div className="flex items-center justify-between gap-2">
          <span className="flex items-center gap-1.5 text-xs font-semibold text-ink-300">
            <Icon name="globe" className="h-3.5 w-3.5 text-ember-400" strokeWidth={2} />
            Company research
          </span>
          <span className="flex items-center gap-2">
            <span
              className={cn(
                "rounded px-1.5 py-0.5 text-[9px] font-extrabold uppercase tracking-wide",
                status === "running"
                  ? "bg-ember-500/15 text-ember-400"
                  : status === "done" && list.length
                    ? "bg-emerald-500/15 text-emerald-400"
                    : status === "error"
                      ? "bg-red-500/15 text-red-400"
                      : "bg-ink-700 text-ink-300"
              )}
            >
              {status === "running"
                ? "Researching"
                : status === "done"
                  ? list.length
                    ? `${list.length} found`
                    : "No match"
                  : status === "error"
                    ? "Offline"
                    : "Ready"}
            </span>
            {q.length >= 2 && status !== "running" && (
              <button
                type="button"
                title="Run the research again"
                aria-label="Run the research again"
                onClick={() => setNonce((n) => n + 1)}
                className="text-ink-400 transition-colors hover:text-ember-400"
              >
                <Icon name="refresh" className="h-3.5 w-3.5" strokeWidth={2.2} />
              </button>
            )}
          </span>
        </div>

        {status === "idle" && (
          <p className="text-[11px] leading-snug text-ink-500">
            Type a company name — research looks up its real, official name and logo. If it has no logo (or isn’t a real
            company), the logo studio below designs one.
          </p>
        )}

        <ResearchSteps steps={steps} />

        {status === "done" && list.length > 0 && (
          <div className="space-y-2 pt-0.5">
            {res?.suggestion && (
              <p className="text-[11px] text-ink-400">
                Showing results for <span className="font-semibold text-ink-200">“{res.suggestion}”</span>
              </p>
            )}
            {shown.map((c) => {
              const inDir = COMPANY_MAP.has(c.qid) || !!findCompanyByName(c.name);
              const busy = adopting?.qid === c.qid;
              const meta = [c.hq || c.country, c.industryLabel || INDUSTRY_NAME[c.industry], c.employees ? `${formatEmployees(c.employees)} employees` : ""]
                .filter(Boolean)
                .join(" · ");
              return (
                <div key={c.qid} className={cn("rounded-lg border bg-ink-900/60 p-2.5", busy ? "border-ember-500/60" : "border-ink-700")}>
                  <div className="flex items-start gap-2.5">
                    <CandidateThumb c={c} />
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-1.5">
                        <span className="text-[13px] font-semibold text-ink-50">{c.name}</span>
                        {(c.logoFile || c.smallLogoFile) && (
                          <span className="rounded bg-emerald-500/15 px-1.5 py-0.5 text-[9px] font-extrabold uppercase tracking-wide text-emerald-400">
                            Logo on file
                          </span>
                        )}
                        {inDir && (
                          <span className="rounded bg-ink-700 px-1.5 py-0.5 text-[9px] font-extrabold uppercase tracking-wide text-ink-300">
                            In directory
                          </span>
                        )}
                      </div>
                      {c.description && <p className="truncate text-[11px] text-ink-400">{c.description}</p>}
                      <p className="truncate text-[10px] text-ink-500">
                        {meta}
                        {c.website ? ` · ${hostOf(c.website)}` : ""}
                      </p>
                    </div>
                    <button
                      type="button"
                      disabled={!!adopting}
                      onClick={() => onUse(c)}
                      aria-label={`Use ${c.name}`}
                      className="flex h-8 shrink-0 items-center gap-1.5 rounded-md bg-ember-500 px-2.5 text-[11px] font-bold text-ink-950 transition-colors hover:bg-ember-400 disabled:cursor-wait disabled:opacity-60"
                    >
                      {busy ? <span className="h-3 w-3 animate-spin rounded-full border-2 border-ink-950/40 border-t-ink-950" /> : <Icon name="check" className="h-3.5 w-3.5" strokeWidth={2.6} />}
                      {busy ? "Adding" : "Use"}
                    </button>
                  </div>
                  {busy && adopting && <ResearchSteps steps={adopting.steps} className="mt-2.5 border-t border-ink-700/70 pt-2.5" />}
                </div>
              );
            })}
            {list.length > 3 && (
              <button type="button" onClick={() => setExpanded((e) => !e)} className="text-[11px] font-semibold text-ink-300 hover:text-ember-400">
                {expanded ? "Show fewer" : `Show ${list.length - 3} more match${list.length - 3 === 1 ? "" : "es"}`}
              </button>
            )}
            <p className="text-[10px] leading-snug text-ink-500">
              Not the one you meant? Keep typing your own name — the logo studio designs an original logo for it.
            </p>
          </div>
        )}

        {status === "done" && !list.length && (
          <p className="flex items-start gap-1.5 rounded-md bg-ink-900/60 p-2 text-[11px] leading-snug text-ink-300">
            <Icon name="sparkle" className="mt-px h-3.5 w-3.5 shrink-0 text-ember-400" strokeWidth={2} />
            <span>
              No real organization matched “{q}”, so the logo studio below designed an original logo for it.
              {res?.blocked ? " Government and law-enforcement agencies aren’t available for ID designs." : ""}
            </span>
          </p>
        )}

        {status === "error" && (
          <div className="flex items-center justify-between gap-2 rounded-md bg-ink-900/60 p-2 text-[11px] text-ink-300">
            <span>Couldn’t reach the research sources (offline?). The logo studio below still designs a logo.</span>
            <button type="button" onClick={() => setNonce((n) => n + 1)} className="shrink-0 font-semibold text-ember-400 hover:text-ember-300">
              Try again
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
