import type { ReactNode } from "react";
import { cn } from "../utils/cn";

export const inputCls =
  "w-full h-10 rounded-lg border border-ink-700 bg-ink-850 px-3 text-sm text-ink-100 placeholder:text-ink-500 outline-none transition-colors focus:border-ember-500/70 focus:bg-ink-900";

export function Field({
  label,
  hint,
  count,
  children,
}: {
  label: string;
  hint?: string;
  count?: string;
  children: ReactNode;
}) {
  return (
    <label className="block">
      <span className="mb-1.5 flex items-baseline justify-between">
        <span className="text-xs font-semibold text-ink-300">{label}</span>
        {count && <span className="text-[10px] tabular-nums text-ink-500">{count}</span>}
      </span>
      {children}
      {hint && <span className="mt-1.5 block text-[11px] leading-snug text-ink-500">{hint}</span>}
    </label>
  );
}

export function Label({ children, aside }: { children: ReactNode; aside?: ReactNode }) {
  return (
    <div className="mb-1.5 flex items-baseline justify-between">
      <span className="text-xs font-semibold text-ink-300">{children}</span>
      {aside && <span className="text-[10px] text-ink-500">{aside}</span>}
    </div>
  );
}

export function Section({ icon, title, children }: { icon: ReactNode; title: string; children: ReactNode }) {
  return (
    <section className="space-y-3.5">
      <h2 className="flex items-center gap-2 text-[11px] font-extrabold uppercase tracking-[0.14em] text-ink-400">
        <span className="text-ember-400">{icon}</span>
        {title}
      </h2>
      {children}
    </section>
  );
}

export interface SegOption<T extends string> {
  value: T;
  label: string;
  icon?: ReactNode;
}

export function Segmented<T extends string>({
  value,
  onChange,
  options,
}: {
  value: T;
  onChange: (v: T) => void;
  options: SegOption<T>[];
}) {
  return (
    <div className="flex gap-0.5 rounded-lg border border-ink-700 bg-ink-850 p-0.5">
      {options.map((o) => (
        <button
          key={o.value}
          type="button"
          onClick={() => onChange(o.value)}
          className={cn(
            "flex h-8 flex-1 items-center justify-center gap-1.5 rounded-md text-xs font-semibold transition-colors",
            value === o.value ? "bg-ink-600 text-ink-50 shadow-sm" : "text-ink-400 hover:text-ink-200"
          )}
        >
          {o.icon}
          {o.label}
        </button>
      ))}
    </div>
  );
}

export function Switch({
  checked,
  onChange,
  label,
}: {
  checked: boolean;
  onChange: (v: boolean) => void;
  label: string;
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      onClick={() => onChange(!checked)}
      className="flex h-10 w-full items-center justify-between rounded-lg border border-ink-700 bg-ink-850 px-3 transition-colors hover:border-ink-600"
    >
      <span className="text-[13px] font-medium text-ink-200">{label}</span>
      <span
        className={cn("relative h-5 w-9 shrink-0 rounded-full transition-colors", checked ? "bg-ember-500" : "bg-ink-700")}
      >
        <span
          className={cn(
            "absolute top-0.5 h-4 w-4 rounded-full bg-white shadow transition-transform",
            checked ? "translate-x-[18px]" : "translate-x-0.5"
          )}
        />
      </span>
    </button>
  );
}
