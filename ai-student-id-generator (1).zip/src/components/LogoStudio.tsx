import { cn } from "../utils/cn";
import { Icon } from "./Icon";
import { INDUSTRIES, INDUSTRY_NAME } from "../lib/industries";
import type { IndustryId } from "../types";
import type { RealStatus } from "./CrestPanel";

export interface LogoOption {
  key: string;
  kind: "real" | "ai" | "auto";
  label: string;
  src: string;
  fit: "cover" | "contain";
  aspect: number;
  dark: boolean;
}

interface Props {
  options: LogoOption[];
  index: number;
  onPick: (i: number) => void;
  /** official-logo lookup state ("idle" for a custom organization) */
  status: RealStatus;
  custom: boolean;
  seed: number;
  onMore: () => void;
  onPrev: () => void;
  industryChoice: IndustryId | "auto";
  detectedIndustry: IndustryId | null;
  onIndustry: (v: IndustryId | "auto") => void;
  brand: string;
  brandSource: "custom" | "logo" | "name";
  onBrand: (hex: string) => void;
  onApplyColors: () => void;
}

const KIND_LABEL: Record<LogoOption["kind"], string> = { real: "Real logo", ai: "AI-drawn mark", auto: "Auto-designed" };
const KIND_STYLE: Record<LogoOption["kind"], string> = {
  real: "bg-emerald-500/15 text-emerald-400",
  ai: "bg-ember-500/15 text-ember-400",
  auto: "bg-ink-700 text-ink-300",
};
const CHIP: Record<LogoOption["kind"], string> = {
  real: "bg-emerald-500 text-ink-950",
  ai: "bg-ember-500 text-ink-950",
  auto: "bg-ink-700 text-ink-100",
};
const SWATCHES = ["#2563eb", "#dc2626", "#16a34a", "#f59e0b", "#7c3aed", "#0891b2", "#db2777", "#ea580c", "#0f766e", "#15181d"];

/** The company-side counterpart of the crest panel: real logo when found + generated concepts. */
export function LogoStudio(p: Props) {
  const opt = p.options[p.index] ?? p.options[0];
  const autoLabel = `Auto · ${INDUSTRY_NAME[p.detectedIndustry ?? "general"]}`;

  return (
    <div className="fade-up space-y-3 rounded-lg border border-ink-700 bg-ink-850 p-3">
      <div className="flex items-center justify-between">
        <span className="flex items-center gap-1.5 text-xs font-semibold text-ink-300">
          <Icon name="sparkle" className="h-3.5 w-3.5 text-ember-400" strokeWidth={2} />
          AI logo studio
        </span>
        {p.options.length > 0 && (
          <span className="text-[10px] tabular-nums text-ink-500">
            {p.index + 1} of {p.options.length}
          </span>
        )}
      </div>

      {p.status === "loading" && (
        <div className="flex items-center gap-2 text-[11px] text-ink-400">
          <span className="h-3 w-3 animate-spin rounded-full border-2 border-ink-500 border-t-ember-400" />
          Looking for the official logo…
        </div>
      )}

      <div className="grid grid-cols-3 gap-2">
        {p.options.map((o, i) => (
          <button
            key={o.key}
            type="button"
            onClick={() => p.onPick(i)}
            aria-pressed={i === p.index}
            aria-label={`Use ${KIND_LABEL[o.kind].toLowerCase()}: ${o.label}`}
            title={o.label}
            className={cn(
              "relative h-16 overflow-hidden rounded-lg border-2 transition-all",
              o.dark ? "bg-ink-900" : "bg-white",
              i === p.index
                ? "border-ember-500 shadow-[0_0_0_3px_rgba(249,123,22,0.15)]"
                : "border-ink-600 opacity-70 hover:opacity-100"
            )}
          >
            <img
              src={o.src}
              alt=""
              draggable={false}
              className={cn("h-full w-full", o.fit === "contain" ? "object-contain p-1.5" : "object-cover")}
            />
            <span className={cn("absolute bottom-1 left-1 rounded px-1 py-px text-[8px] font-extrabold uppercase tracking-wide", CHIP[o.kind])}>
              {o.kind === "real" ? "Real" : o.kind === "ai" ? "AI" : "Auto"}
            </span>
          </button>
        ))}
        <button
          type="button"
          onClick={p.onMore}
          aria-label="Generate 4 more logo concepts"
          title="Generate 4 more logo concepts"
          className="flex h-16 flex-col items-center justify-center gap-1 rounded-lg border border-dashed border-ink-600 text-ink-300 transition-colors hover:border-ember-500/60 hover:text-ember-400"
        >
          <span key={p.seed} className={cn("flex", p.seed > 0 && "spin-once")}>
            <Icon name="refresh" className="h-4 w-4" strokeWidth={2.2} />
          </span>
          <span className="text-[9px] font-extrabold uppercase tracking-wide">More ideas</span>
        </button>
      </div>

      {opt && (
        <p className="text-[11px] leading-snug text-ink-400">
          <span className={cn("mr-1.5 inline-block rounded px-1.5 py-0.5 text-[9px] font-extrabold uppercase tracking-wide", KIND_STYLE[opt.kind])}>
            {KIND_LABEL[opt.kind]}
          </span>
          {opt.label}
        </p>
      )}

      <div className="flex items-center justify-between text-[11px] text-ink-500">
        <span>Concept set {p.seed + 1}</span>
        <button
          type="button"
          disabled={p.seed === 0}
          onClick={p.onPrev}
          className="font-semibold text-ink-300 hover:text-ember-400 disabled:cursor-not-allowed disabled:opacity-40"
        >
          ← Previous set
        </button>
      </div>

      <div className="grid grid-cols-2 gap-2.5 border-t border-ink-700/70 pt-3">
        <label className="block">
          <span className="mb-1 block text-[11px] font-semibold text-ink-400">Industry</span>
          <select
            value={p.industryChoice}
            onChange={(e) => p.onIndustry(e.target.value as IndustryId | "auto")}
            aria-label="Industry for the logo concepts"
            className="h-9 w-full rounded-md border border-ink-700 bg-ink-900 px-2 text-xs font-medium text-ink-200 outline-none focus:border-ember-500/70"
          >
            <option value="auto">{autoLabel}</option>
            {INDUSTRIES.map((i) => (
              <option key={i.id} value={i.id}>
                {i.name}
              </option>
            ))}
          </select>
        </label>
        <div>
          <span className="mb-1 block text-[11px] font-semibold text-ink-400">Brand color</span>
          <div className="flex h-9 items-center gap-2 rounded-md border border-ink-700 bg-ink-900 px-2">
            <label
              className="relative h-6 w-6 shrink-0 cursor-pointer overflow-hidden rounded-md ring-1 ring-white/15 focus-within:ring-2 focus-within:ring-ember-500/80"
              style={{ background: p.brand }}
              title="Pick a brand color"
            >
              <input
                type="color"
                aria-label="Pick a brand color"
                className="swatch absolute inset-0 opacity-0"
                value={p.brand}
                onChange={(e) => p.onBrand(e.target.value)}
              />
            </label>
            <span className="min-w-0 flex-1 truncate font-mono text-[11px] text-ink-300">{p.brand}</span>
            {p.brandSource === "custom" && (
              <button type="button" onClick={() => p.onBrand("")} className="text-[10px] font-bold uppercase text-ink-400 hover:text-ember-400">
                Auto
              </button>
            )}
          </div>
        </div>
      </div>

      <div className="flex flex-wrap items-center gap-1.5">
        {SWATCHES.map((c) => (
          <button
            key={c}
            type="button"
            onClick={() => p.onBrand(c)}
            aria-label={`Brand color ${c}`}
            className={cn(
              "h-5 w-5 rounded-full ring-1 ring-white/15 transition-transform hover:scale-110",
              p.brand.toLowerCase() === c && "ring-2 ring-ember-400"
            )}
            style={{ background: c }}
          />
        ))}
        <span className="ml-auto text-[10px] text-ink-500">
          {p.brandSource === "logo" ? "Detected from the official logo" : p.brandSource === "name" ? "Picked from the name" : "Your color"}
        </span>
      </div>

      <button
        type="button"
        onClick={p.onApplyColors}
        className="flex h-9 w-full items-center justify-center gap-2 rounded-lg border border-ink-600 text-[12px] font-semibold text-ink-200 transition-colors hover:border-ember-500/60 hover:text-ember-300"
      >
        <span className="h-3.5 w-3.5 rounded-full ring-1 ring-white/20" style={{ background: p.brand }} />
        Use brand colors on the card
      </button>

      <p className="text-[10px] leading-snug text-ink-500">
        {opt?.kind === "real"
          ? "Logos are trademarks of their owners. Found via Wikidata, hosted on Wikimedia Commons."
          : p.custom
            ? "Concepts are built from the name, industry and brand color around 18 marks drawn by an image model — designed right in your browser."
            : p.status === "error"
              ? "Couldn’t reach Wikimedia to load the official logo (offline?) — showing generated concepts instead."
              : p.status === "none"
                ? "No official logo found for this organization, so these are generated concepts — not the real mark."
                : "Generated concepts pair the name with marks drawn by an image model, matched to the industry."}
      </p>
    </div>
  );
}
