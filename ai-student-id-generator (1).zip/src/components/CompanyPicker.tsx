import { useEffect, useMemo, useRef, useState } from "react";
import { cn } from "../utils/cn";
import { Icon } from "./Icon";
import { SP500_COUNT, formatEmployees, searchCompanies, type Company, type CompanyGroup } from "../lib/companies";
import { INDUSTRIES, INDUSTRY_NAME } from "../lib/industries";
import { bundledCompanyLogoUrl, hasCompanyLogo } from "../lib/logos";
import { orgInitials } from "../lib/logoStudio";
import type { IndustryId } from "../types";

interface Props {
  /** "custom" or a company id */
  value: string;
  customName: string;
  onChange: (id: string) => void;
  /** directory + organizations found by research (researched ones first) */
  companies: Company[];
  /** logos of researched organizations (data URLs), keyed by company id */
  researchedLogos: Record<string, string>;
  /** hand a search query over to live research */
  onResearch: (query: string) => void;
  /** the logo the card is currently using (may be a real logo loaded online or a generated concept) */
  selectedLogo?: { src: string; contain: boolean } | null;
}

const PAGE = 60;
const TILE = ["#2563eb", "#dc2626", "#059669", "#d97706", "#7c3aed", "#0891b2", "#db2777", "#ea580c", "#0f766e", "#475569"];
const GROUPS: { v: CompanyGroup; label: string }[] = [
  { v: "all", label: "All" },
  { v: "sp500", label: "S&P 500" },
  { v: "other", label: "Other" },
];

function tileColor(name: string) {
  let h = 0;
  for (let i = 0; i < name.length; i++) h = (h * 31 + name.charCodeAt(i)) >>> 0;
  return TILE[h % TILE.length];
}

function Thumb({ c, logo, className }: { c: Company; logo: string | null; className: string }) {
  if (logo) {
    return <img src={logo} alt="" loading="lazy" className={cn(className, "shrink-0 rounded-lg bg-white object-contain p-1")} />;
  }
  return (
    <span
      className={cn(className, "flex shrink-0 items-center justify-center rounded-lg text-[11px] font-bold text-white")}
      style={{ background: tileColor(c.name) }}
    >
      {orgInitials(c.name)}
    </span>
  );
}

function subline(c: Company) {
  if (c.researched && c.description) return [c.description, c.hq].filter(Boolean).join(" · ");
  return [c.hq, INDUSTRY_NAME[c.industry], c.employees ? `${formatEmployees(c.employees)} employees` : ""].filter(Boolean).join(" · ");
}

/**
 * Searchable dropdown of notable organizations (S&P 500, large U.S. employers, well-known private companies,
 * health systems & nonprofits) plus everything you've researched. Anything else can be researched live.
 */
export function CompanyPicker({ value, customName, onChange, companies, researchedLogos, onResearch, selectedLogo }: Props) {
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState("");
  const [industry, setIndustry] = useState<IndustryId | "all">("all");
  const [group, setGroup] = useState<CompanyGroup>("all");
  const [limit, setLimit] = useState(PAGE);
  const [active, setActive] = useState(0);
  const wrapRef = useRef<HTMLDivElement>(null);
  const listRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const byId = useMemo(() => new Map(companies.map((c) => [c.id, c])), [companies]);
  const selected = value !== "custom" ? byId.get(value) ?? null : null;
  const results = useMemo(
    () => (open ? searchCompanies(q, industry, group, companies) : []),
    [open, q, industry, group, companies]
  );
  const researchedCount = useMemo(() => companies.filter((c) => c.researched).length, [companies]);
  const logoOf = (c: Company) => researchedLogos[c.id] ?? bundledCompanyLogoUrl(c.id);

  useEffect(() => {
    if (!open) return;
    const onDown = (e: MouseEvent) => {
      if (wrapRef.current && !wrapRef.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", onDown);
    return () => document.removeEventListener("mousedown", onDown);
  }, [open]);

  useEffect(() => {
    if (open) inputRef.current?.focus();
  }, [open]);

  useEffect(() => {
    if (!open) return;
    listRef.current?.querySelector(`[data-idx="${active}"]`)?.scrollIntoView({ block: "nearest" });
  }, [active, open]);

  const resetPaging = () => {
    setLimit(PAGE);
    setActive(0);
    listRef.current?.scrollTo({ top: 0 });
  };

  const pick = (id: string) => {
    onChange(id);
    setOpen(false);
    setQ("");
  };

  const research = () => {
    const query = q.trim();
    if (!query) return;
    onResearch(query);
    setOpen(false);
    setQ("");
  };

  const onKey = (e: React.KeyboardEvent) => {
    if (e.key === "Escape") {
      setOpen(false);
    } else if (e.key === "ArrowDown") {
      e.preventDefault();
      const next = Math.min(active + 1, results.length - 1);
      if (next >= limit) setLimit((l) => l + PAGE);
      setActive(next);
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setActive((a) => Math.max(0, a - 1));
    } else if (e.key === "Enter") {
      e.preventDefault();
      const r = results[active];
      if (r) pick(r.id);
      else research();
    }
  };

  const shown = results.slice(0, limit);

  return (
    <div ref={wrapRef} className="relative">
      <button
        type="button"
        aria-haspopup="listbox"
        aria-expanded={open}
        aria-label="Choose a company or organization"
        onClick={() => setOpen((o) => !o)}
        className={cn(
          "flex h-14 w-full items-center gap-3 rounded-lg border bg-ink-850 px-3 text-left transition-colors",
          open ? "border-ember-500/70" : "border-ink-700 hover:border-ink-500"
        )}
      >
        {selectedLogo ? (
          <img
            src={selectedLogo.src}
            alt=""
            className={cn("h-9 w-9 shrink-0 rounded-lg bg-white", selectedLogo.contain ? "object-contain p-1" : "object-cover")}
          />
        ) : selected ? (
          <Thumb c={selected} logo={logoOf(selected)} className="h-9 w-9" />
        ) : (
          <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-ink-700 text-ink-300">
            <Icon name="building" className="h-5 w-5" />
          </span>
        )}
        <span className="min-w-0 flex-1">
          <span className="block truncate text-[13px] font-semibold text-ink-50">
            {selected ? selected.name : customName.trim() || "Your organization"}
          </span>
          <span className="block truncate text-[11px] text-ink-400">
            {selected ? subline(selected) : "Custom name · researched automatically"}
          </span>
        </span>
        <Icon name="chevron" className={cn("h-4 w-4 shrink-0 text-ink-400 transition-transform", open && "rotate-180")} />
      </button>

      {open && (
        <div
          className="fade-up absolute inset-x-0 top-full z-40 mt-2 overflow-hidden rounded-xl border border-ink-600 bg-ink-900 shadow-[0_24px_60px_-12px_rgba(0,0,0,0.7)]"
          onKeyDown={onKey}
        >
          <div className="relative border-b border-ink-700 p-2.5">
            <Icon name="search" className="pointer-events-none absolute left-5 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-400" />
            <input
              ref={inputRef}
              value={q}
              onChange={(e) => {
                setQ(e.target.value);
                resetPaging();
              }}
              placeholder="Search company, city or ticker…"
              aria-label="Search companies"
              className="h-10 w-full rounded-lg border border-ink-700 bg-ink-850 pl-9 pr-3 text-sm text-ink-100 outline-none placeholder:text-ink-500 focus:border-ember-500/70"
            />
          </div>

          <div className="flex items-center gap-2 border-b border-ink-700 px-2.5 py-2">
            <select
              aria-label="Filter by industry"
              value={industry}
              onChange={(e) => {
                setIndustry(e.target.value as IndustryId | "all");
                resetPaging();
              }}
              className="h-8 min-w-0 flex-1 rounded-md border border-ink-700 bg-ink-850 px-2 text-xs font-medium text-ink-200 outline-none focus:border-ember-500/70"
            >
              <option value="all">All industries</option>
              {INDUSTRIES.map((i) => (
                <option key={i.id} value={i.id}>
                  {i.name}
                </option>
              ))}
            </select>
            <div className="flex shrink-0 gap-0.5 rounded-md border border-ink-700 bg-ink-850 p-0.5">
              {GROUPS.map((g) => (
                <button
                  key={g.v}
                  type="button"
                  onClick={() => {
                    setGroup(g.v);
                    resetPaging();
                  }}
                  className={cn(
                    "h-7 rounded px-2 text-[11px] font-semibold transition-colors",
                    group === g.v ? "bg-ink-600 text-ink-50" : "text-ink-400 hover:text-ink-200"
                  )}
                >
                  {g.label}
                </button>
              ))}
            </div>
          </div>

          {q.trim().length >= 2 && (
            <button
              type="button"
              onClick={research}
              className="flex w-full items-center gap-3 border-b border-ink-700 bg-ember-500/5 px-3 py-2.5 text-left transition-colors hover:bg-ember-500/10"
            >
              <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-ember-500/15 text-ember-400">
                <Icon name="globe" className="h-4 w-4" strokeWidth={2} />
              </span>
              <span className="min-w-0">
                <span className="block truncate text-[13px] font-semibold text-ink-100">Research “{q.trim()}” online</span>
                <span className="block text-[11px] text-ink-400">Finds the real name & official logo — designs one if none exists</span>
              </span>
            </button>
          )}

          <button
            type="button"
            onClick={() => pick("custom")}
            className={cn(
              "flex w-full items-center gap-3 border-b border-ink-700 px-3 py-2.5 text-left transition-colors hover:bg-ink-800",
              value === "custom" && "bg-ember-500/10"
            )}
          >
            <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-ink-700 text-ink-300">
              <Icon name="sparkle" className="h-4 w-4" strokeWidth={2} />
            </span>
            <span className="min-w-0">
              <span className="block text-[13px] font-semibold text-ink-100">Type a name instead</span>
              <span className="block text-[11px] text-ink-400">Any company — research finds it, or the studio designs a logo</span>
            </span>
          </button>

          <div className="flex items-center justify-between px-3 pb-1 pt-2 text-[10px] font-bold uppercase tracking-[0.12em] text-ink-500">
            <span>
              {results.length.toLocaleString()} of {companies.length.toLocaleString()} organizations
            </span>
            <span className="font-medium normal-case tracking-normal">
              {researchedCount ? `${researchedCount} researched · ` : ""}
              {SP500_COUNT} in the S&P 500
            </span>
          </div>

          <div
            ref={listRef}
            role="listbox"
            className="slim-scroll max-h-[300px] overflow-y-auto pb-1.5"
            onScroll={(e) => {
              const el = e.currentTarget;
              if (el.scrollTop + el.clientHeight > el.scrollHeight - 240 && limit < results.length) {
                setLimit((l) => l + PAGE);
              }
            }}
          >
            {shown.map((c, idx) => {
              const isSel = c.id === value;
              return (
                <button
                  key={c.id}
                  type="button"
                  role="option"
                  aria-selected={isSel}
                  data-idx={idx}
                  onMouseEnter={() => setActive(idx)}
                  onClick={() => pick(c.id)}
                  className={cn(
                    "flex w-full items-center gap-3 px-3 py-2 text-left transition-colors",
                    idx === active ? "bg-ink-800" : "bg-transparent",
                    isSel && "bg-ember-500/10"
                  )}
                >
                  <Thumb c={c} logo={logoOf(c)} className="h-8 w-8" />
                  <span className="min-w-0 flex-1">
                    <span className="flex items-center gap-1.5">
                      <span className="truncate text-[13px] font-semibold text-ink-100">{c.name}</span>
                      {c.researched ? (
                        <span className="shrink-0 rounded bg-sky-500/15 px-1.5 py-0.5 text-[9px] font-extrabold uppercase tracking-wide text-sky-300">
                          Researched
                        </span>
                      ) : (
                        hasCompanyLogo(c.id) && (
                          <span className="shrink-0 rounded bg-emerald-500/15 px-1.5 py-0.5 text-[9px] font-extrabold uppercase tracking-wide text-emerald-400">
                            Real logo
                          </span>
                        )
                      )}
                      {c.sp500 && (
                        <span className="shrink-0 rounded bg-ink-700 px-1.5 py-0.5 text-[9px] font-extrabold uppercase tracking-wide text-ink-300">
                          {c.id}
                        </span>
                      )}
                    </span>
                    <span className="block truncate text-[11px] text-ink-400">{subline(c)}</span>
                  </span>
                  {isSel && <Icon name="check" className="h-4 w-4 shrink-0 text-ember-400" strokeWidth={2.6} />}
                </button>
              );
            })}

            {results.length === 0 && (
              <div className="px-4 py-8 text-center">
                <p className="text-sm font-semibold text-ink-200">Not in the directory</p>
                <p className="mt-1 text-xs text-ink-500">Use “Research online” above to look it up — press Enter.</p>
              </div>
            )}

            {limit < results.length && (
              <button
                type="button"
                onClick={() => setLimit((l) => l + PAGE * 3)}
                className="mx-3 mt-1 w-[calc(100%-1.5rem)] rounded-lg border border-ink-700 py-2 text-xs font-semibold text-ink-300 hover:border-ink-500 hover:text-ink-100"
              >
                Show more ({(results.length - limit).toLocaleString()} left)
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
