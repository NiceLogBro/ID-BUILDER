import { cn } from "../utils/cn";
import { Icon } from "./Icon";
import type { ResearchStep } from "../lib/research";

/** The research "work log": each lookup the app made and what it found. */
export function ResearchSteps({ steps, className }: { steps: ResearchStep[]; className?: string }) {
  if (!steps.length) return null;
  return (
    <ol className={cn("space-y-1.5", className)}>
      {steps.map((s) => (
        <li key={s.id} className="flex items-start gap-2 text-[11px] leading-snug">
          <span className="mt-px flex h-3.5 w-3.5 shrink-0 items-center justify-center">
            {s.state === "running" ? (
              <span className="h-3 w-3 animate-spin rounded-full border-2 border-ink-600 border-t-ember-400" />
            ) : s.state === "done" ? (
              <Icon name="check" className="h-3.5 w-3.5 text-emerald-400" strokeWidth={3} />
            ) : s.state === "warn" ? (
              <Icon name="alert" className="h-3.5 w-3.5 text-amber-400" strokeWidth={2.2} />
            ) : (
              <Icon name="close" className="h-3.5 w-3.5 text-red-400" strokeWidth={2.6} />
            )}
          </span>
          <span className="min-w-0">
            <span className={cn(s.state === "running" ? "text-ink-200" : "text-ink-300")}>{s.label}</span>
            {s.detail && <span className="block truncate text-ink-500">{s.detail}</span>}
          </span>
        </li>
      ))}
    </ol>
  );
}
