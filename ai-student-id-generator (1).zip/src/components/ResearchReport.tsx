import type { ReactNode } from "react";
import { Icon } from "./Icon";
import { ResearchSteps } from "./ResearchSteps";
import { commonsPageUrl, hostOf, wikidataUrl, type ResearchedOrg, type ResearchStep } from "../lib/research";
import { formatEmployees } from "../lib/companies";
import { INDUSTRY_NAME } from "../lib/industries";
import { orgInitials } from "../lib/logoStudio";

interface Props {
  org: ResearchedOrg;
  /** work log while a refresh is running */
  steps: ResearchStep[] | null;
  onRefresh: () => void;
  onEdit: () => void;
  onForget: () => void;
}

function Fact({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="min-w-0">
      <div className="text-[9px] font-extrabold uppercase tracking-[0.12em] text-ink-500">{label}</div>
      <div className="truncate text-[12px] text-ink-200">{children}</div>
    </div>
  );
}

/** What research found about the selected organization, with links to every source. */
export function ResearchReport({ org, steps, onRefresh, onEdit, onForget }: Props) {
  const domain = hostOf(org.website);
  const busy = !!steps;
  return (
    <div className="fade-up space-y-3 rounded-lg border border-ink-700 bg-ink-850 p-3">
      <div className="flex items-center justify-between">
        <span className="flex items-center gap-1.5 text-xs font-semibold text-ink-300">
          <Icon name="globe" className="h-3.5 w-3.5 text-ember-400" strokeWidth={2} />
          Research report
        </span>
        <span className="rounded bg-emerald-500/15 px-1.5 py-0.5 text-[9px] font-extrabold uppercase tracking-wide text-emerald-400">
          Real organization
        </span>
      </div>

      <div className="flex items-start gap-3">
        {org.logo ? (
          <img
            src={org.logo.url}
            alt=""
            className={`h-12 w-12 shrink-0 rounded-lg object-contain p-1 ${org.logo.dark ? "bg-ink-900" : "bg-white"}`}
          />
        ) : (
          <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg bg-ink-700 text-sm font-bold text-ink-200">
            {orgInitials(org.name)}
          </span>
        )}
        <div className="min-w-0">
          <div className="text-[14px] font-bold leading-tight text-ink-50">{org.name}</div>
          {org.description && <p className="mt-0.5 text-[11px] leading-snug text-ink-400">{org.description}</p>}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-x-3 gap-y-2">
        <Fact label="Headquarters">{[org.hq, org.country].filter(Boolean).join(", ") || "—"}</Fact>
        <Fact label="Industry">
          <span title={org.industryLabel ? `${org.industryLabel} · ${INDUSTRY_NAME[org.industry]}` : undefined}>
            {INDUSTRY_NAME[org.industry]}
          </span>
        </Fact>
        <Fact label="Employees">{org.employees ? formatEmployees(org.employees) : "—"}</Fact>
        <Fact label="Founded">{org.founded || "—"}</Fact>
        {org.ticker && <Fact label="Ticker">{org.ticker}</Fact>}
        <Fact label="Website">
          {domain ? (
            <a href={org.website} target="_blank" rel="noreferrer" className="text-ink-200 underline-offset-2 hover:text-ember-400 hover:underline">
              {domain}
            </a>
          ) : (
            "—"
          )}
        </Fact>
      </div>

      <div className="space-y-1 rounded-md bg-ink-900/60 p-2 text-[11px] leading-snug text-ink-400">
        <div className="flex items-start gap-1.5">
          <Icon name={org.logo ? "check" : "sparkle"} className={`mt-px h-3.5 w-3.5 shrink-0 ${org.logo ? "text-emerald-400" : "text-ember-400"}`} strokeWidth={2.4} />
          <span>
            {org.logoSource === "commons" ? (
              <>
                Official logo from Wikimedia Commons —{" "}
                <a href={commonsPageUrl(org.logoNote)} target="_blank" rel="noreferrer" className="text-ink-200 underline-offset-2 hover:text-ember-400 hover:underline">
                  {org.logoNote}
                </a>
              </>
            ) : org.logoSource === "website" ? (
              <>Brand icon from {org.logoNote}</>
            ) : (
              <>No usable logo on file anywhere — the logo studio designed one for it.</>
            )}
          </span>
        </div>
        <div className="flex items-center gap-1.5">
          <Icon name="external" className="h-3.5 w-3.5 shrink-0 text-ink-500" />
          <span>
            Records:{" "}
            <a href={wikidataUrl(org.qid)} target="_blank" rel="noreferrer" className="text-ink-200 underline-offset-2 hover:text-ember-400 hover:underline">
              Wikidata {org.qid}
            </a>{" "}
            · researched {new Date(org.researchedAt).toLocaleDateString()}
          </span>
        </div>
      </div>

      {steps && <ResearchSteps steps={steps} />}

      <div className="grid grid-cols-3 gap-2">
        <button
          type="button"
          onClick={onRefresh}
          disabled={busy}
          className="flex h-8 items-center justify-center gap-1.5 rounded-md border border-ink-600 text-[11px] font-semibold text-ink-200 transition-colors hover:border-ember-500/60 hover:text-ember-300 disabled:cursor-wait disabled:opacity-60"
        >
          <Icon name="refresh" className="h-3.5 w-3.5" strokeWidth={2.2} />
          Refresh
        </button>
        <button
          type="button"
          onClick={onEdit}
          disabled={busy}
          className="flex h-8 items-center justify-center rounded-md border border-ink-600 text-[11px] font-semibold text-ink-200 transition-colors hover:border-ink-400 disabled:opacity-60"
        >
          Change name
        </button>
        <button
          type="button"
          onClick={onForget}
          disabled={busy}
          className="flex h-8 items-center justify-center rounded-md border border-ink-700 text-[11px] font-semibold text-ink-400 transition-colors hover:border-red-500/50 hover:text-red-300 disabled:opacity-60"
        >
          Forget
        </button>
      </div>
    </div>
  );
}
