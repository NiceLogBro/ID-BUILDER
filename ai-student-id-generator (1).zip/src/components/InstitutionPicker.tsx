import { useEffect, useMemo, useRef, useState } from "react";
import { cn } from "../utils/cn";
import { Icon } from "./Icon";
import {
  CONTROL_LABEL,
  INSTITUTIONS,
  INSTITUTION_MAP,
  LEVEL_LABEL,
  STATES,
  crestThumb,
  isFeatured,
  searchInstitutions,
  type Institution,
} from "../lib/institutions";
import { hasRealLogo } from "../lib/logos";

interface Props {
  /** "none" or an institution id */
  value: string;
  onChange: (id: string) => void;
  /** the crest the card is currently using for the selected school (may be a logo loaded online) */
  selectedCrest?: { src: string; contain: boolean } | null;
}

const PAGE = 60;
const LEVELS: { v: number; label: string }[] = [
  { v: 0, label: "All" },
  { v: 1, label: "4-year" },
  { v: 2, label: "2-year" },
  { v: 3, label: "Other" },
];

function CrestImg({ inst, className }: { inst: Institution; className: string }) {
  const t = crestThumb(inst);
  return (
    <img
      src={t.src}
      alt=""
      loading="lazy"
      className={cn(className, "shrink-0 rounded-lg bg-white", t.contain ? "object-contain p-1" : "object-cover")}
    />
  );
}

function subline(i: Institution) {
  return `${i.city}, ${i.state} · ${CONTROL_LABEL[i.control]} · ${LEVEL_LABEL[i.level]}`;
}

/**
 * Searchable dropdown of every active U.S. college/university (IPEDS) — ~6,000 entries.
 * Rows render in pages as you scroll, so it stays instant.
 */
export function InstitutionPicker({ value, onChange, selectedCrest }: Props) {
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState("");
  const [state, setState] = useState("ALL");
  const [level, setLevel] = useState(0);
  const [limit, setLimit] = useState(PAGE);
  const [active, setActive] = useState(0);
  const wrapRef = useRef<HTMLDivElement>(null);
  const listRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const selected = value !== "none" ? INSTITUTION_MAP.get(value) ?? null : null;
  const results = useMemo(() => (open ? searchInstitutions(q, state, level) : []), [open, q, state, level]);

  useEffect(() => {
    if (!open) return;
    const onDown = (e: MouseEvent) => {
      if (wrapRef.current && !wrapRef.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", onDown);
    return () => document.removeEventListener("mousedown", onDown);
  }, [open]);

  useEffect(() => {
    if (open) inputRef.current?.focus();
  }, [open]);

  useEffect(() => {
    if (!open) return;
    listRef.current?.querySelector(`[data-idx="${active}"]`)?.scrollIntoView({ block: "nearest" });
  }, [active, open]);

  const resetPaging = () => {
    setLimit(PAGE);
    setActive(0);
    listRef.current?.scrollTo({ top: 0 });
  };

  const pick = (id: string) => {
    onChange(id);
    setOpen(false);
    setQ("");
  };

  const onKey = (e: React.KeyboardEvent) => {
    if (e.key === "Escape") {
      setOpen(false);
    } else if (e.key === "ArrowDown") {
      e.preventDefault();
      const next = Math.min(active + 1, results.length - 1);
      if (next >= limit) setLimit((l) => l + PAGE);
      setActive(next);
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setActive((a) => Math.max(0, a - 1));
    } else if (e.key === "Enter") {
      e.preventDefault();
      const r = results[active];
      if (r) pick(r.id);
    }
  };

  const shown = results.slice(0, limit);

  return (
    <div ref={wrapRef} className="relative">
      <button
        type="button"
        aria-haspopup="listbox"
        aria-expanded={open}
        onClick={() => setOpen((o) => !o)}
        className={cn(
          "flex h-14 w-full items-center gap-3 rounded-lg border bg-ink-850 px-3 text-left transition-colors",
          open ? "border-ember-500/70" : "border-ink-700 hover:border-ink-500"
        )}
      >
        {selected ? (
          selectedCrest ? (
          <img
            src={selectedCrest.src}
            alt=""
            className={cn("h-9 w-9 shrink-0 rounded-lg bg-white", selectedCrest.contain ? "object-contain p-1" : "object-cover")}
          />
        ) : (
          <CrestImg inst={selected} className="h-9 w-9" />
        )
        ) : (
          <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-ink-700 text-ink-300">
            <Icon name="building" className="h-5 w-5" />
          </span>
        )}
        <span className="min-w-0 flex-1">
          <span className="block truncate text-[13px] font-semibold text-ink-50">
            {selected ? selected.name : "Own company / organization"}
          </span>
          <span className="block truncate text-[11px] text-ink-400">
            {selected ? `${selected.city}, ${selected.state} · ${LEVEL_LABEL[selected.level]}` : "Letter logo · type the name below"}
          </span>
        </span>
        <Icon name="chevron" className={cn("h-4 w-4 shrink-0 text-ink-400 transition-transform", open && "rotate-180")} />
      </button>

      {open && (
        <div
          className="fade-up absolute inset-x-0 top-full z-40 mt-2 overflow-hidden rounded-xl border border-ink-600 bg-ink-900 shadow-[0_24px_60px_-12px_rgba(0,0,0,0.7)]"
          onKeyDown={onKey}
        >
          {/* search */}
          <div className="relative border-b border-ink-700 p-2.5">
            <Icon name="search" className="pointer-events-none absolute left-5 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-400" />
            <input
              ref={inputRef}
              value={q}
              onChange={(e) => {
                setQ(e.target.value);
                resetPaging();
              }}
              placeholder="Search name, city or state…"
              aria-label="Search institutions"
              className="h-10 w-full rounded-lg border border-ink-700 bg-ink-850 pl-9 pr-3 text-sm text-ink-100 outline-none placeholder:text-ink-500 focus:border-ember-500/70"
            />
          </div>

          {/* filters */}
          <div className="flex items-center gap-2 border-b border-ink-700 px-2.5 py-2">
            <select
              aria-label="Filter by state"
              value={state}
              onChange={(e) => {
                setState(e.target.value);
                resetPaging();
              }}
              className="h-8 min-w-0 flex-1 rounded-md border border-ink-700 bg-ink-850 px-2 text-xs font-medium text-ink-200 outline-none focus:border-ember-500/70"
            >
              <option value="ALL">All states &amp; territories</option>
              {STATES.map((s) => (
                <option key={s.code} value={s.code}>
                  {s.name}
                </option>
              ))}
            </select>
            <div className="flex shrink-0 gap-0.5 rounded-md border border-ink-700 bg-ink-850 p-0.5">
              {LEVELS.map((l) => (
                <button
                  key={l.v}
                  type="button"
                  onClick={() => {
                    setLevel(l.v);
                    resetPaging();
                  }}
                  className={cn(
                    "h-7 rounded px-2 text-[11px] font-semibold transition-colors",
                    level === l.v ? "bg-ink-600 text-ink-50" : "text-ink-400 hover:text-ink-200"
                  )}
                >
                  {l.label}
                </button>
              ))}
            </div>
          </div>

          {/* pinned option */}
          <button
            type="button"
            onClick={() => pick("none")}
            className={cn(
              "flex w-full items-center gap-3 border-b border-ink-700 px-3 py-2.5 text-left transition-colors hover:bg-ink-800",
              value === "none" && "bg-ember-500/10"
            )}
          >
            <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-ink-700 text-ink-300">
              <Icon name="building" className="h-4 w-4" />
            </span>
            <span className="min-w-0">
              <span className="block text-[13px] font-semibold text-ink-100">Company or organization instead</span>
              <span className="block text-[11px] text-ink-400">Switch to the company directory &amp; AI logo studio</span>
            </span>
          </button>

          <div className="flex items-center justify-between px-3 pb-1 pt-2 text-[10px] font-bold uppercase tracking-[0.12em] text-ink-500">
            <span>
              {results.length.toLocaleString()} of {INSTITUTIONS.length.toLocaleString()} institutions
            </span>
            <span className="font-medium normal-case tracking-normal">↑↓ to browse · Enter to pick</span>
          </div>

          {/* list */}
          <div
            ref={listRef}
            role="listbox"
            className="slim-scroll max-h-[300px] overflow-y-auto pb-1.5"
            onScroll={(e) => {
              const el = e.currentTarget;
              if (el.scrollTop + el.clientHeight > el.scrollHeight - 240 && limit < results.length) {
                setLimit((l) => l + PAGE);
              }
            }}
          >
            {shown.map((inst, idx) => {
              const isSel = inst.id === value;
              return (
                <button
                  key={inst.id}
                  type="button"
                  role="option"
                  aria-selected={isSel}
                  data-idx={idx}
                  onMouseEnter={() => setActive(idx)}
                  onClick={() => pick(inst.id)}
                  className={cn(
                    "flex w-full items-center gap-3 px-3 py-2 text-left transition-colors",
                    idx === active ? "bg-ink-800" : "bg-transparent",
                    isSel && "bg-ember-500/10"
                  )}
                >
                  <CrestImg inst={inst} className="h-8 w-8" />
                  <span className="min-w-0 flex-1">
                    <span className="flex items-center gap-1.5">
                      <span className="truncate text-[13px] font-semibold text-ink-100">{inst.name}</span>
                      {hasRealLogo(inst.id) ? (
                        <span className="shrink-0 rounded bg-emerald-500/15 px-1.5 py-0.5 text-[9px] font-extrabold uppercase tracking-wide text-emerald-400">
                          Real logo
                        </span>
                      ) : isFeatured(inst.id) ? (
                        <span className="shrink-0 rounded bg-ember-500/15 px-1.5 py-0.5 text-[9px] font-extrabold uppercase tracking-wide text-ember-400">
                          AI crest
                        </span>
                      ) : null}
                    </span>
                    <span className="block truncate text-[11px] text-ink-400">{subline(inst)}</span>
                  </span>
                  {isSel && <Icon name="check" className="h-4 w-4 shrink-0 text-ember-400" strokeWidth={2.6} />}
                </button>
              );
            })}

            {results.length === 0 && (
              <div className="px-4 py-8 text-center">
                <p className="text-sm font-semibold text-ink-200">No institutions match</p>
                <p className="mt-1 text-xs text-ink-500">
                  Try fewer words, or choose “Own company / organization” and type the name yourself.
                </p>
              </div>
            )}

            {limit < results.length && (
              <button
                type="button"
                onClick={() => setLimit((l) => l + PAGE * 3)}
                className="mx-3 mt-1 w-[calc(100%-1.5rem)] rounded-lg border border-ink-700 py-2 text-xs font-semibold text-ink-300 hover:border-ink-500 hover:text-ink-100"
              >
                Show more ({(results.length - limit).toLocaleString()} left)
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
