import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "./index.css";
import { installFonts } from "./lib/fonts";
import App from "./App";

installFonts();

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <App />
  </StrictMode>
);
