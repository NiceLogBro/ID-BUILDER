import { useEffect, useMemo, useRef, useState } from "react";
import { cn } from "./utils/cn";
import { Icon } from "./components/Icon";
import { CardSvg } from "./components/card/CardSvg";
import { CARD_SIZE, type CardInput } from "./components/card/model";
import { InstitutionPicker } from "./components/InstitutionPicker";
import { CompanyPicker } from "./components/CompanyPicker";
import { LogoStudio, type LogoOption } from "./components/LogoStudio";
import { ResearchBox } from "./components/ResearchBox";
import { ResearchReport } from "./components/ResearchReport";
import { AvatarPicker } from "./components/AvatarPicker";
import { StylePicker } from "./components/StylePicker";
import { CustomColors } from "./components/CustomColors";
import { ScenePicker } from "./components/ScenePicker";
import { CrestPanel, type RealStatus } from "./components/CrestPanel";
import { Field, Label, Section, Segmented, Switch, inputCls } from "./components/ui";
import {
  ROLES,
  ROLE_FIELDS,
  ROLE_ID_LABEL,
  ROLE_LABEL,
  type BadgeData,
  type CapsMode,
  type IndustryId,
  type OrgMode,
  type Orientation,
  type Role,
  type SceneId,
} from "./types";
import { AVATAR_COUNT, avatarUrl } from "./lib/avatars";
import { applyCaps, copyText, fileToPhoto, formatExpiry, genId, getQRDataUrl, initials, qrPayload } from "./lib/badge";
import { exportSceneAsPng, exportSvgAsPng } from "./lib/export";
import { fontsReady } from "./lib/fonts";
import { INSTITUTIONS, INSTITUTION_MAP, crestGuesses } from "./lib/institutions";
import { COMPANIES, COMPANY_MAP, findCompanyByName, type Company } from "./lib/companies";
import {
  hostOf,
  loadResearched,
  researchById,
  researchLogo,
  saveResearched,
  type OrgCandidate,
  type ResearchStep,
  type ResearchedOrg,
} from "./lib/research";
import { INDUSTRY_NAME, isIndustry, suggestionsFor } from "./lib/industries";
import { autoBrandColor, clearConceptCache, generateConcepts } from "./lib/logoStudio";
import { COMPANY_LOGO_COUNT, REAL_LOGO_COUNT, loadCompanyLogo, loadRealLogo, type RealLogo } from "./lib/logos";
import { crestPalette } from "./lib/crest";
import { LAYOUT_META, applyCustomColors, brandToCustom, getStyles, isHexColor } from "./lib/styles";
import { randomScene, sceneById } from "./lib/scenes";
import { resetTextCache } from "./lib/text";

const STORAGE_KEY = "badgesmith:v2";
const LEGACY_KEY = "badgesmith:v1";
const STANFORD = "243744";

function defaultBadge(): BadgeData {
  return {
    name: "Jordan Ellis",
    title: "Computer Science",
    department: "School of Engineering",
    company: "Halcyon Labs",
    college: STANFORD,
    guess: 0,
    empId: "20481936",
    role: "student",
    expires: new Date(Date.now() + 365 * 864e5).toISOString().slice(0, 10),
    orientation: "portrait",
    styleSeed: 0,
    styleIndex: 0,
    caps: "auto",
    showQr: true,
    showBarcode: true,
    photo: null,
    avatarId: 30,
    customOn: false,
    customBg: "#232936",
    customAccent: "#ff8a3d",
    customText: "#f4f5f7",
    customPlate: "#f4f5f7",
    scene: "studio" as SceneId,
    orgMode: "university",
    companyId: "custom",
    industry: "auto",
    brandColor: "",
    logoSeed: 0,
    logoPick: 0,
  };
}

function sanitize(p: Partial<BadgeData>): BadgeData {
  const out = { ...defaultBadge(), ...p } as BadgeData;
  if (!ROLES.includes(out.role)) out.role = "staff";
  if (out.college !== "none" && !INSTITUTION_MAP.has(out.college)) out.college = "none";
  // older saves had no mode: "no school picked" meant they were using their own organization
  if (p.orgMode !== "university" && p.orgMode !== "company") out.orgMode = out.college === "none" ? "company" : "university";
  if (
    typeof out.companyId !== "string" ||
    (out.companyId !== "custom" && !out.companyId.startsWith("r:Q") && !COMPANY_MAP.has(out.companyId))
  )
    out.companyId = "custom";
  if (out.industry !== "auto" && !isIndustry(out.industry)) out.industry = "auto";
  if (typeof out.brandColor !== "string" || (out.brandColor !== "" && !isHexColor(out.brandColor))) out.brandColor = "";
  out.logoSeed = Number.isInteger(out.logoSeed) && out.logoSeed >= 0 ? out.logoSeed : 0;
  out.logoPick = Number.isInteger(out.logoPick) && out.logoPick >= 0 ? out.logoPick : 0;
  out.guess = Number.isInteger(out.guess) && out.guess >= 0 ? out.guess : 0;
  out.styleSeed = Number.isInteger(out.styleSeed) && out.styleSeed >= 0 ? out.styleSeed : 0;
  out.styleIndex = [0, 1, 2, 3].includes(out.styleIndex) ? out.styleIndex : 0;
  out.avatarId =
    typeof out.avatarId === "number" && out.avatarId >= 0 && out.avatarId < Math.max(1, AVATAR_COUNT)
      ? Math.floor(out.avatarId)
      : null;
  out.photo = typeof out.photo === "string" ? out.photo : null;
  if (out.orientation !== "landscape") out.orientation = "portrait";
  out.customOn = out.customOn === true;
  const dflt = defaultBadge();
  (["customBg", "customAccent", "customText", "customPlate"] as const).forEach((k) => {
    if (!isHexColor(out[k] ?? "")) out[k] = dflt[k];
    else out[k] = (out[k] as string).toLowerCase();
  });
  const sceneIds: SceneId[] = ["studio", "granite", "walnut", "marble", "slate"];
  if (!sceneIds.includes(out.scene)) out.scene = "studio";
  return out;
}

function loadSaved(): BadgeData {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return sanitize(JSON.parse(raw));
    // carry over what still makes sense from the first version of the app
    const old = localStorage.getItem(LEGACY_KEY);
    if (old) {
      const o = JSON.parse(old);
      const collegeMap: Record<string, string> = { mit: "166683", stanford: STANFORD, harvard: "166027" };
      return sanitize({
        name: o.name,
        title: o.title,
        department: o.department,
        company: o.company,
        empId: o.empId,
        expires: o.expires,
        orientation: o.orientation,
        caps: o.caps,
        showQr: o.showQr,
        showBarcode: o.showBarcode,
        photo: o.photo,
        role: o.role === "intern" ? "intern" : "staff",
        college: collegeMap[o.college] ?? "none",
        avatarId: o.photo ? null : 30,
      });
    }
  } catch {
    /* corrupted storage — fall through */
  }
  return defaultBadge();
}

interface Toast {
  id: number;
  msg: string;
  kind: "ok" | "err";
}

function Chips({ items, active, onPick }: { items: string[]; active: string; onPick: (v: string) => void }) {
  return (
    <div className="flex flex-wrap gap-1.5">
      {items.map((s) => (
        <button
          key={s}
          type="button"
          onClick={() => onPick(s)}
          className={cn(
            "rounded-full border px-2.5 py-0.5 text-[11px] font-medium transition-colors",
            active === s
              ? "border-ember-500/70 bg-ember-500/10 text-ember-300"
              : "border-ink-700 text-ink-300 hover:border-ink-500 hover:text-ink-100"
          )}
        >
          {s}
        </button>
      ))}
    </div>
  );
}

export default function App() {
  const [data, setData] = useState<BadgeData>(loadSaved);
  const [qrUrl, setQrUrl] = useState("");
  const [zoom, setZoom] = useState(() =>
    typeof window === "undefined" ? 0.8 : window.innerWidth < 640 ? 0.7 : window.innerHeight >= 780 ? 1 : 0.8
  );
  const [exporting, setExporting] = useState(false);
  const [savingScene, setSavingScene] = useState(false);
  const [toast, setToast] = useState<Toast | null>(null);
  const [fontTick, setFontTick] = useState(0);
  const toastTimer = useRef<number | null>(null);
  const svgRef = useRef<SVGSVGElement>(null);
  // organizations found by live research (saved in this browser) + the lookup currently running
  const [researched, setResearched] = useState<ResearchedOrg[]>(loadResearched);
  const [adopting, setAdopting] = useState<{ qid: string; steps: ResearchStep[] } | null>(null);
  const adoptCtrl = useRef<AbortController | null>(null);

  /* ---------------------------- derived values ---------------------------- */
  const portrait = data.orientation === "portrait";
  const dims = CARD_SIZE[data.orientation];
  const fields = ROLE_FIELDS[data.role];
  const displayName = data.name.trim() ? applyCaps(data.name.trim(), data.caps) : "";

  /* --------------------------- organization --------------------------- */
  const isUni = data.orgMode === "university";
  const inst = isUni && data.college !== "none" ? INSTITUTION_MAP.get(data.college) ?? null : null;
  const researchedCompanies = useMemo<Company[]>(
    () =>
      researched.map((r) => ({
        id: r.id,
        name: r.name,
        hq: [r.hq, r.country].filter(Boolean).join(", "),
        industry: r.industry,
        sp500: false,
        employees: r.employees,
        lname: r.name.toLowerCase(),
        hay: `${r.name} ${r.hq} ${r.country} ${r.description}`.toLowerCase(),
        researched: true,
        description: r.description,
        website: r.website,
      })),
    [researched]
  );
  const allCompanies = useMemo(() => [...researchedCompanies, ...COMPANIES], [researchedCompanies]);
  const researchedLogos = useMemo(
    () => Object.fromEntries(researched.flatMap((r) => (r.logo ? [[r.id, r.logo.url]] : []))) as Record<string, string>,
    [researched]
  );
  const researchedRec = !isUni && data.companyId.startsWith("r:") ? researched.find((r) => r.id === data.companyId) ?? null : null;
  const company =
    !isUni && data.companyId !== "custom"
      ? researchedRec
        ? researchedCompanies.find((c) => c.id === researchedRec.id) ?? null
        : COMPANY_MAP.get(data.companyId) ?? null
      : null;

  // official-logo lookup — universities by IPEDS id, directory companies by id (researched ones carry their own logo)
  const logoKey = inst ? `u:${inst.id}` : company && !researchedRec ? `c:${company.id}` : "";
  const [real, setReal] = useState<{ key: string; status: RealStatus; logo: RealLogo | null }>({
    key: "",
    status: "idle",
    logo: null,
  });
  useEffect(() => {
    if (!logoKey) {
      setReal({ key: "", status: "idle", logo: null });
      return;
    }
    let alive = true;
    setReal({ key: logoKey, status: "loading", logo: null });
    const id = logoKey.slice(2);
    void (logoKey.startsWith("u:") ? loadRealLogo(id) : loadCompanyLogo(id)).then((r) => {
      if (alive) setReal({ key: logoKey, status: r.status, logo: r.status === "found" ? r.logo : null });
    });
    return () => {
      alive = false;
    };
  }, [logoKey]);
  const realLogo = researchedRec ? researchedRec.logo : logoKey && real.key === logoKey ? real.logo : null;
  const realStatus: RealStatus = researchedRec
    ? researchedRec.logo
      ? "found"
      : "none"
    : !logoKey
      ? "idle"
      : real.key === logoKey
        ? real.status
        : "loading";

  const orgName = isUni ? (inst ? inst.name : "") : company ? company.name : data.company.trim();
  const detectedIndustry: IndustryId | null = company ? company.industry : null;
  const industry: IndustryId = data.industry !== "auto" ? data.industry : detectedIndustry ?? (isUni ? "education" : "general");

  // brand / school color: your pick → detected from the official logo → derived from the name
  const brandSource: "custom" | "logo" | "name" = isHexColor(data.brandColor) ? "custom" : realLogo?.brand ? "logo" : "name";
  const brand =
    brandSource === "custom"
      ? data.brandColor
      : realLogo?.brand
        ? realLogo.brand
        : isUni
          ? crestPalette(orgName || "University")[0]
          : autoBrandColor(orgName || "Your Company");

  // universities: real logo + drawn crest guesses
  const guesses = useMemo(() => (inst ? crestGuesses(inst, realLogo) : []), [inst, realLogo]);
  const guessIdx = guesses.length ? data.guess % guesses.length : 0;

  // companies: real logo + AI logo studio concepts
  const concepts = useMemo(
    () => (isUni ? [] : generateConcepts(orgName || "Your Company", industry, brand, data.logoSeed)),
    // fontTick: re-render the concepts once the web fonts are ready
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [isUni, orgName, industry, brand, data.logoSeed, fontTick]
  );
  const logoOptions: LogoOption[] = useMemo(() => {
    const list: LogoOption[] = [];
    if (company && realLogo) {
      list.push({
        key: "real",
        kind: "real",
        label: researchedRec
          ? researchedRec.logoSource === "website"
            ? `Brand icon from ${researchedRec.logoNote} — found by research`
            : "Official logo — found by research on Wikimedia Commons"
          : "The organization’s official logo",
        src: realLogo.url,
        fit: "contain",
        aspect: realLogo.aspect,
        dark: realLogo.dark,
      });
    }
    for (const c of concepts) list.push(c);
    if (researchedRec?.lowResIcon) {
      const ic = researchedRec.lowResIcon;
      list.push({
        key: "icon",
        kind: "real",
        label: `Small website icon from ${hostOf(researchedRec.website)} (low resolution)`,
        src: ic.url,
        fit: "contain",
        aspect: ic.aspect,
        dark: ic.dark,
      });
    }
    return list;
  }, [company, realLogo, concepts, researchedRec]);
  const logoIdx = logoOptions.length ? data.logoPick % logoOptions.length : 0;

  const crest: { src: string; fit: "cover" | "contain"; aspect: number; dark: boolean } | null = isUni
    ? guesses[guessIdx] ?? null
    : logoOptions[logoIdx] ?? null;
  const crestUrl = crest ? crest.src : null;
  const institution = orgName;
  const sugg = suggestionsFor(data.orgMode, industry, data.role);

  const imageUrl = data.photo ?? (data.avatarId !== null ? avatarUrl(data.avatarId) || null : null);

  const styles = useMemo(() => getStyles(data.styleSeed), [data.styleSeed]);

  // Custom colors override whichever of the 4 styles is selected (thumbnails + preview + export).
  const customSet = useMemo(
    () => ({ bg: data.customBg, accent: data.customAccent, text: data.customText, plate: data.customPlate }),
    [data.customBg, data.customAccent, data.customText, data.customPlate]
  );
  const displayStyles = useMemo(
    () => (data.customOn ? styles.map((s) => ({ ...s, palette: applyCustomColors(s.palette, customSet) })) : styles),
    [styles, data.customOn, customSet]
  );
  const style = displayStyles[data.styleIndex % displayStyles.length];
  const baseStyle = styles[data.styleIndex % styles.length];
  const scene = sceneById(data.scene);

  const base: Omit<CardInput, "style"> = {
    portrait,
    W: dims.W,
    H: dims.H,
    name: displayName,
    initials: initials(data.name),
    title: data.title,
    department: data.department,
    institution,
    crestUrl,
    crestFit: crest ? crest.fit : "cover",
    crestAspect: crest ? crest.aspect : 1,
    crestDark: crest ? crest.dark : false,
    imageUrl,
    role: data.role,
    roleLabel: ROLE_LABEL[data.role],
    idLabel: ROLE_ID_LABEL[data.role],
    empId: data.empId,
    expires: formatExpiry(data.expires),
    qrUrl,
    showQr: data.showQr,
    showBarcode: data.showBarcode,
  };
  const model: CardInput = { ...base, style };

  /* -------------------------------- effects ------------------------------- */
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    } catch {
      /* quota — ignore */
    }
  }, [data]);

  useEffect(() => {
    saveResearched(researched);
  }, [researched]);

  useEffect(() => {
    if (!data.showQr) {
      setQrUrl("");
      return;
    }
    let alive = true;
    getQRDataUrl(qrPayload(data, institution)).then((u) => {
      if (alive) setQrUrl(u);
    });
    return () => {
      alive = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data.name, data.empId, data.role, data.expires, institution, data.showQr]);

  // Text is measured to lay the card out; re-measure (and re-render logo concepts) once the fonts load.
  useEffect(() => {
    let alive = true;
    fontsReady.then(() => {
      if (!alive) return;
      resetTextCache();
      clearConceptCache();
      setFontTick((t) => t + 1);
    });
    return () => {
      alive = false;
    };
  }, []);

  /* ------------------------------- handlers ------------------------------- */
  const set = <K extends keyof BadgeData>(key: K, value: BadgeData[K]) => setData((d) => ({ ...d, [key]: value }));

  const showToast = (msg: string, kind: Toast["kind"] = "ok") => {
    if (toastTimer.current) window.clearTimeout(toastTimer.current);
    setToast({ id: Date.now(), msg, kind });
    toastTimer.current = window.setTimeout(() => setToast(null), 2600);
  };

  const pickSchool = (id: string) => {
    if (id === "none") {
      setData((d) => ({ ...d, orgMode: "company", companyId: "custom", logoPick: 0 }));
      return;
    }
    setData((d) => ({ ...d, college: id, guess: 0 }));
  };

  const pickCompany = (id: string) =>
    setData((d) => ({ ...d, orgMode: "company", companyId: id, logoPick: 0, logoSeed: 0, industry: "auto", brandColor: "" }));

  /* ------------------------------- research ------------------------------- */
  const trackSteps = (qid: string) => {
    const log: ResearchStep[] = [];
    setAdopting({ qid, steps: [] });
    return (s: ResearchStep) => {
      const i = log.findIndex((x) => x.id === s.id);
      if (i >= 0) log[i] = s;
      else log.push(s);
      setAdopting({ qid, steps: [...log] });
    };
  };

  /** Add a researched organization: fetch its real logo (or note that none exists, so the studio designs one). */
  const adoptCandidate = async (c: OrgCandidate) => {
    const dir = COMPANY_MAP.get(c.qid) ?? findCompanyByName(c.name);
    if (dir) {
      pickCompany(dir.id);
      showToast(`${dir.name} is in the directory — selected it`);
      return;
    }
    adoptCtrl.current?.abort();
    const ctrl = new AbortController();
    adoptCtrl.current = ctrl;
    const push = trackSteps(c.qid);
    try {
      const found = await researchLogo(c, push, ctrl.signal);
      const rec: ResearchedOrg = { ...c, ...found, id: `r:${c.qid}`, researchedAt: Date.now() };
      setResearched((list) => [rec, ...list.filter((x) => x.id !== rec.id)]);
      setData((d) => ({
        ...d,
        orgMode: "company",
        companyId: rec.id,
        company: rec.name.slice(0, 40),
        logoPick: 0,
        logoSeed: 0,
        industry: "auto",
        brandColor: "",
      }));
      showToast(found.logo ? `${rec.name} added with its real logo` : `${rec.name} added — no logo on file, so the studio designed one`);
    } catch {
      if (!ctrl.signal.aborted) showToast("Research was interrupted — try again", "err");
    } finally {
      if (adoptCtrl.current === ctrl) {
        adoptCtrl.current = null;
        setAdopting(null);
      }
    }
  };

  const refreshResearch = async () => {
    const rec = researchedRec;
    if (!rec || adoptCtrl.current) return;
    const ctrl = new AbortController();
    adoptCtrl.current = ctrl;
    const push = trackSteps(rec.qid);
    try {
      const fresh = (await researchById(rec.qid, push, ctrl.signal)) ?? rec;
      const found = await researchLogo(fresh, push, ctrl.signal);
      const next: ResearchedOrg = { ...rec, ...fresh, ...found, id: rec.id, researchedAt: Date.now() };
      setResearched((list) => list.map((x) => (x.id === rec.id ? next : x)));
      setData((d) => ({ ...d, company: next.name.slice(0, 40), logoPick: 0 }));
      showToast(found.logo ? "Research refreshed — real logo found" : "Research refreshed");
    } catch {
      if (!ctrl.signal.aborted) showToast("Couldn’t refresh the research", "err");
    } finally {
      if (adoptCtrl.current === ctrl) {
        adoptCtrl.current = null;
        setAdopting(null);
      }
    }
  };

  const editResearched = () => {
    if (researchedRec) setData((d) => ({ ...d, companyId: "custom", company: researchedRec.name.slice(0, 40), logoPick: 0 }));
  };

  const forgetResearched = () => {
    if (!researchedRec) return;
    const { id, name } = researchedRec;
    setResearched((list) => list.filter((x) => x.id !== id));
    setData((d) => ({ ...d, companyId: "custom", company: name.slice(0, 40), logoPick: 0 }));
    showToast(`${name} removed from your researched organizations`);
  };

  /** "Research … online" from the directory search box. */
  const researchQuery = (q: string) =>
    setData((d) => ({
      ...d,
      orgMode: "company",
      companyId: "custom",
      company: q.slice(0, 40),
      logoPick: 0,
      logoSeed: 0,
      industry: "auto",
      brandColor: "",
    }));

  const applyBrandColors = () => {
    const c = brandToCustom(brand);
    setData((d) => ({ ...d, customOn: true, customBg: c.bg, customAccent: c.accent, customText: c.text, customPlate: c.plate }));
    showToast(isUni ? "School colors applied to the card" : "Brand colors applied to the card");
  };

  const handleExport = async () => {
    if (exporting || !svgRef.current) return;
    setExporting(true);
    try {
      await fontsReady;
      const slug = (displayName || "badge").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "badge";
      await exportSvgAsPng(svgRef.current, dims.W, dims.H, `${slug}-${data.role}-id.png`);
      showToast("PNG saved to downloads");
    } catch {
      showToast("Export failed — try again", "err");
    } finally {
      setExporting(false);
    }
  };

  const handleCopy = async () => {
    const where = inst ? ` (${inst.city}, ${inst.state})` : company && company.hq ? ` (${company.hq})` : "";
    const lines = [
      `Name: ${data.name || "—"}`,
      `Role: ${ROLE_LABEL[data.role]}`,
      `${fields.title}: ${data.title || "—"}`,
      `${fields.dept}: ${data.department || "—"}`,
      `${isUni ? "Institution" : "Organization"}: ${institution || "—"}${where}`,
      ...(isUni ? [] : [`Industry: ${INDUSTRY_NAME[industry]}`, ...(company?.website ? [`Website: ${company.website}`] : [])]),
      `${ROLE_ID_LABEL[data.role]}: ${data.empId || "—"}`,
      `Expires: ${data.expires || "—"}`,
    ];
    const ok = await copyText(lines.join("\n"));
    showToast(ok ? "Badge details copied" : "Couldn't access clipboard", ok ? "ok" : "err");
  };

  const handleUpload = async (file: File) => {
    try {
      const url = await fileToPhoto(file);
      set("photo", url);
      showToast("Photo added to badge");
    } catch {
      showToast("Couldn't read that image", "err");
    }
  };

  const shuffleAvatar = () =>
    setData((d) => {
      if (!AVATAR_COUNT) return d;
      let n = Math.floor(Math.random() * AVATAR_COUNT);
      if (n === d.avatarId) n = (n + 1) % AVATAR_COUNT;
      return { ...d, avatarId: n, photo: null };
    });

  const handleReset = () => {
    setData(defaultBadge());
    showToast("Badge reset to defaults");
  };

  const randomBackdrop = () => {
    const s = randomScene(data.scene === "studio" ? undefined : data.scene);
    set("scene", s.id);
    showToast(`Backdrop: ${s.name}`);
  };

  const handleSaveScene = async () => {
    if (savingScene || !svgRef.current) return;
    setSavingScene(true);
    try {
      await fontsReady;
      const slug = (displayName || "badge").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "badge";
      await exportSceneAsPng({
        svg: svgRef.current,
        cardW: dims.W,
        cardH: dims.H,
        backdropSrc: scene?.src ?? null,
        tiltDeg: scene?.tilt ?? 0,
        fileName: `${slug}-${data.role}-id-scene.png`,
      });
      showToast(scene ? `Picture saved — ${scene.name}` : "Studio picture saved");
    } catch {
      showToast("Couldn't save the picture", "err");
    } finally {
      setSavingScene(false);
    }
  };

  const idTitle = `${ROLE_LABEL[data.role]} ID`;

  return (
    <div className="flex h-screen flex-col bg-ink-950 font-ui">
      {/* header */}
      <header className="flex h-14 shrink-0 items-center justify-between border-b border-ink-800 bg-ink-900/70 px-4 backdrop-blur sm:px-5">
        <div className="flex items-center gap-3">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-ember-500 text-ink-950">
            <Icon name="logo" className="h-4.5 w-4.5" strokeWidth={2} />
          </div>
          <div className="leading-tight">
            <div className="font-display text-[15px] font-bold tracking-tight text-ink-50">BadgeSmith</div>
            <div className="hidden whitespace-nowrap text-[10px] font-semibold uppercase tracking-[0.18em] text-ink-500 sm:block">
              Campus &amp; company IDs
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleCopy}
            className="flex h-9 items-center gap-2 rounded-lg border border-ink-700 bg-ink-850 px-3 text-[13px] font-semibold text-ink-200 transition-colors hover:border-ink-600 hover:bg-ink-800"
          >
            <Icon name="copy" className="h-4 w-4" />
            <span className="hidden sm:inline">Copy details</span>
            <span className="sm:hidden">Copy</span>
          </button>
          <button
            type="button"
            onClick={handleExport}
            disabled={exporting}
            className="flex h-9 items-center gap-2 whitespace-nowrap rounded-lg bg-ember-500 px-3.5 text-[13px] font-bold text-ink-950 transition-colors hover:bg-ember-400 disabled:cursor-wait disabled:opacity-70"
          >
            {exporting ? (
              <span className="h-4 w-4 animate-spin rounded-full border-2 border-ink-950/40 border-t-ink-950" />
            ) : (
              <Icon name="download" className="h-4 w-4" strokeWidth={2.2} />
            )}
            {exporting ? (
              "Exporting…"
            ) : (
              <>
                <span className="hidden sm:inline">Export PNG</span>
                <span className="sm:hidden">Export</span>
              </>
            )}
          </button>
        </div>
      </header>

      <main className="grid min-h-0 flex-1 grid-cols-1 overflow-y-auto lg:grid-cols-[420px_1fr] lg:overflow-hidden">
        {/* form panel */}
        <aside className="slim-scroll order-2 min-h-0 overflow-y-auto border-t border-ink-800 bg-ink-900/40 px-5 py-6 lg:order-1 lg:border-r lg:border-t-0">
          <div className="mx-auto max-w-[380px] space-y-9">
            {/* IDENTITY */}
            <Section icon={<Icon name="user" className="h-3.5 w-3.5" strokeWidth={2.2} />} title="Identity">
              <Field label="Full name" count={`${data.name.length}/40`} hint="Type it and watch it land on the card.">
                <input
                  autoFocus
                  className={cn(inputCls, "h-11 text-base font-semibold")}
                  value={data.name}
                  maxLength={40}
                  placeholder="e.g. Jordan Ellis"
                  onChange={(e) => set("name", e.target.value)}
                />
              </Field>
              <div>
                <Label>I am a…</Label>
                <Segmented<Role>
                  value={data.role}
                  onChange={(v) => set("role", v)}
                  options={ROLES.map((r) => ({ value: r, label: ROLE_LABEL[r] }))}
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <Field label={fields.title}>
                  <input
                    className={inputCls}
                    value={data.title}
                    maxLength={36}
                    placeholder={fields.titlePh}
                    onChange={(e) => set("title", e.target.value)}
                  />
                </Field>
                <Field label={fields.dept}>
                  <input
                    className={inputCls}
                    value={data.department}
                    maxLength={24}
                    placeholder={fields.deptPh}
                    onChange={(e) => set("department", e.target.value)}
                  />
                </Field>
              </div>
              <div className="space-y-2 rounded-lg border border-ink-800 bg-ink-900/40 p-2.5">
                <div className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-[0.12em] text-ink-500">
                  <Icon name="sparkle" className="h-3 w-3 text-ember-400" strokeWidth={2} />
                  Quick picks · {isUni ? "University" : INDUSTRY_NAME[industry]}
                </div>
                <Chips items={sugg.titles} active={data.title} onPick={(v) => set("title", v)} />
                <Chips items={sugg.depts} active={data.department} onPick={(v) => set("department", v)} />
              </div>
            </Section>

            {/* ORGANIZATION */}
            <Section icon={<Icon name="building" className="h-3.5 w-3.5" strokeWidth={2.2} />} title="Organization">
              <Segmented<OrgMode>
                value={data.orgMode}
                onChange={(v) => set("orgMode", v)}
                options={[
                  { value: "university", label: "University", icon: <Icon name="badge" className="h-3.5 w-3.5" strokeWidth={2} /> },
                  { value: "company", label: "Company / Org", icon: <Icon name="building" className="h-3.5 w-3.5" strokeWidth={2} /> },
                ]}
              />

              {isUni ? (
                <>
                  <div>
                    <Label aside={`${INSTITUTIONS.length.toLocaleString()} U.S. institutions`}>College or university</Label>
                    <InstitutionPicker
                      value={data.college}
                      selectedCrest={crest ? { src: crest.src, contain: crest.fit === "contain" } : null}
                      onChange={pickSchool}
                    />
                    <p className="mt-1.5 text-[11px] leading-snug text-ink-500">
                      Official logos are listed for {REAL_LOGO_COUNT.toLocaleString()} schools. Any other school gets a drawn
                      guess.
                    </p>
                  </div>
                  {inst && guesses.length > 0 && (
                    <CrestPanel
                      guesses={guesses}
                      index={guessIdx}
                      status={realStatus}
                      onPick={(i) => set("guess", i)}
                      brand={brand}
                      onApplyColors={applyBrandColors}
                    />
                  )}
                </>
              ) : (
                <>
                  <div>
                    <Label aside={`${allCompanies.length.toLocaleString()} organizations`}>Company or organization</Label>
                    <CompanyPicker
                      value={data.companyId}
                      customName={data.company}
                      companies={allCompanies}
                      researchedLogos={researchedLogos}
                      onResearch={researchQuery}
                      selectedLogo={crest ? { src: crest.src, contain: crest.fit === "contain" } : null}
                      onChange={pickCompany}
                    />
                    <p className="mt-1.5 text-[11px] leading-snug text-ink-500">
                      Pick from the directory ({COMPANY_LOGO_COUNT.toLocaleString()} official logos) — or type any name and
                      research finds the real company and its logo. No logo anywhere? The studio designs one.
                    </p>
                  </div>
                  {(data.companyId === "custom" || (data.companyId.startsWith("r:") && !researchedRec)) && (
                    <ResearchBox
                      name={data.company}
                      onName={(v) => set("company", v)}
                      onUse={(c) => void adoptCandidate(c)}
                      adopting={adopting}
                    />
                  )}
                  {researchedRec && (
                    <ResearchReport
                      org={researchedRec}
                      steps={adopting && adopting.qid === researchedRec.qid ? adopting.steps : null}
                      onRefresh={() => void refreshResearch()}
                      onEdit={editResearched}
                      onForget={forgetResearched}
                    />
                  )}
                  <LogoStudio
                    options={logoOptions}
                    index={logoIdx}
                    onPick={(i) => set("logoPick", i)}
                    status={realStatus}
                    custom={data.companyId === "custom"}
                    seed={data.logoSeed}
                    onMore={() => setData((d) => ({ ...d, logoSeed: d.logoSeed + 1 }))}
                    onPrev={() => setData((d) => ({ ...d, logoSeed: Math.max(0, d.logoSeed - 1) }))}
                    industryChoice={data.industry}
                    detectedIndustry={detectedIndustry}
                    onIndustry={(v) => set("industry", v)}
                    brand={brand}
                    brandSource={brandSource}
                    onBrand={(hex) => set("brandColor", hex)}
                    onApplyColors={applyBrandColors}
                  />
                </>
              )}
            </Section>

            {/* ID */}
            <Section icon={<Icon name="badge" className="h-3.5 w-3.5" strokeWidth={2.2} />} title="ID details">
              <div className="grid grid-cols-2 gap-3">
                <Field label={idTitle}>
                  <div className="relative">
                    <input
                      className={cn(inputCls, "pr-10 font-mono tracking-wide")}
                      value={data.empId}
                      maxLength={14}
                      placeholder="20481936"
                      onChange={(e) => set("empId", e.target.value.replace(/[^A-Za-z0-9-]/g, "").toUpperCase())}
                    />
                    <button
                      type="button"
                      title="Generate a random ID"
                      aria-label="Generate a random ID"
                      onClick={() => set("empId", genId(data.role))}
                      className="absolute right-1.5 top-1/2 flex h-7 w-7 -translate-y-1/2 items-center justify-center rounded-md text-ink-400 transition-colors hover:bg-ink-700 hover:text-ember-400"
                    >
                      <Icon name="dice" className="h-4 w-4" />
                    </button>
                  </div>
                </Field>
                <Field label="Expires">
                  <input
                    type="date"
                    className={cn(inputCls, "tabular-nums")}
                    value={data.expires}
                    onChange={(e) => set("expires", e.target.value)}
                  />
                </Field>
              </div>
            </Section>

            {/* PROFILE PICTURE */}
            <Section icon={<Icon name="camera" className="h-3.5 w-3.5" strokeWidth={2.2} />} title="Profile picture">
              <AvatarPicker
                avatarId={data.avatarId}
                photo={data.photo}
                initials={initials(data.name)}
                onPick={(id) => setData((d) => ({ ...d, avatarId: id, photo: null }))}
                onNone={() => setData((d) => ({ ...d, avatarId: null, photo: null }))}
                onShuffle={shuffleAvatar}
                onUpload={(f) => void handleUpload(f)}
                onRemovePhoto={() => set("photo", null)}
              />
            </Section>

            {/* CARD STYLE */}
            <Section icon={<Icon name="palette" className="h-3.5 w-3.5" strokeWidth={2} />} title="Card style">
              <div>
                <Label>Orientation</Label>
                <Segmented<Orientation>
                  value={data.orientation}
                  onChange={(v) => set("orientation", v)}
                  options={[
                    { value: "portrait", label: "Portrait", icon: <Icon name="portrait" className="h-3.5 w-3.5" strokeWidth={2} /> },
                    { value: "landscape", label: "Landscape", icon: <Icon name="landscape" className="h-3.5 w-3.5" strokeWidth={2} /> },
                  ]}
                />
              </div>
              <StylePicker
                base={base}
                styles={displayStyles}
                index={data.styleIndex}
                seed={data.styleSeed}
                onPick={(i) => set("styleIndex", i)}
                onRefresh={() => set("styleSeed", data.styleSeed + 1)}
                onPrev={() => set("styleSeed", Math.max(0, data.styleSeed - 1))}
                onOriginals={() => set("styleSeed", 0)}
              />
              <CustomColors
                enabled={data.customOn}
                colors={customSet}
                base={baseStyle.palette}
                onToggle={(v) => set("customOn", v)}
                onChange={(patch) => {
                  const mapped: Partial<BadgeData> = {};
                  if (patch.bg !== undefined) mapped.customBg = patch.bg;
                  if (patch.accent !== undefined) mapped.customAccent = patch.accent;
                  if (patch.text !== undefined) mapped.customText = patch.text;
                  if (patch.plate !== undefined) mapped.customPlate = patch.plate;
                  setData((d) => ({ ...d, ...mapped }));
                }}
                onReset={() =>
                  setData((d) => ({
                    ...d,
                    customBg: baseStyle.palette.bg,
                    customAccent: baseStyle.palette.accent,
                    customText: baseStyle.palette.text,
                    customPlate: baseStyle.palette.plate,
                  }))
                }
              />
              <div>
                <Label aside={scene ? scene.name : "Studio"}>Display backdrop</Label>
                <ScenePicker
                  value={data.scene}
                  onPick={(id) => set("scene", id)}
                  onRandom={randomBackdrop}
                  onSave={() => void handleSaveScene()}
                  saving={savingScene}
                />
              </div>
            </Section>

            {/* OPTIONS */}
            <Section icon={<Icon name="sparkle" className="h-3.5 w-3.5" strokeWidth={2} />} title="Options">
              <div>
                <Label>Name style</Label>
                <Segmented<CapsMode>
                  value={data.caps}
                  onChange={(v) => set("caps", v)}
                  options={[
                    { value: "auto", label: "As typed" },
                    { value: "upper", label: "UPPER" },
                    { value: "title", label: "Title Case" },
                  ]}
                />
                <p className="mt-1.5 text-[11px] text-ink-500">Only changes the printed casing, not what you typed.</p>
              </div>
              <div className="space-y-2">
                <Switch checked={data.showQr} onChange={(v) => set("showQr", v)} label="QR code" />
                <Switch checked={data.showBarcode} onChange={(v) => set("showBarcode", v)} label="Barcode" />
              </div>
            </Section>

            <div className="border-t border-ink-800 pt-5">
              <button
                type="button"
                onClick={handleReset}
                className="flex h-9 w-full items-center justify-center gap-2 rounded-lg border border-ink-700 text-[13px] font-semibold text-ink-400 transition-colors hover:border-ink-500 hover:text-ink-200"
              >
                <Icon name="reset" className="h-4 w-4" />
                Reset to defaults
              </button>
              <p className="mt-3 text-center text-[11px] text-ink-500">Everything is saved locally in your browser.</p>
              <p className="mt-2 text-center text-[10px] leading-relaxed text-ink-600">
                For design mockups only — these cards aren’t valid credentials. School and company names and logos are
                trademarks of their owners.
              </p>
            </div>
          </div>
        </aside>

        {/* preview stage */}
        <div
          className={cn(
            "relative order-1 flex min-h-[56vh] flex-col border-ink-800 bg-ink-950 lg:order-2 lg:min-h-0 lg:border-l",
            !scene && "dotgrid"
          )}
          style={scene ? { backgroundImage: `url("${scene.src}")`, backgroundSize: "cover", backgroundPosition: "center" } : undefined}
        >
          {scene && (
            <>
              <div aria-hidden className="pointer-events-none absolute inset-0" style={{ background: "rgba(3,5,9,0.42)" }} />
              <div
                aria-hidden
                className="pointer-events-none absolute inset-0"
                style={{ background: "radial-gradient(ellipse 88% 72% at 50% 46%, rgba(0,0,0,0) 32%, rgba(0,0,0,0.62) 100%)" }}
              />
              <div
                aria-hidden
                className="pointer-events-none absolute inset-0"
                style={{
                  background:
                    "linear-gradient(180deg, rgba(8,10,14,0.55), rgba(8,10,14,0.05) 30%, rgba(8,10,14,0.1) 70%, rgba(8,10,14,0.62))",
                }}
              />
            </>
          )}
          <div
            className={cn(
              "relative flex h-12 shrink-0 items-center justify-between border-b border-ink-800/70 px-4",
              scene && "border-ink-800/40 bg-ink-950/70 backdrop-blur-sm"
            )}
          >
            <div className="flex items-center gap-1">
              <button
                type="button"
                aria-label="Zoom out"
                onClick={() => setZoom((z) => Math.max(0.4, +(z - 0.1).toFixed(2)))}
                className="flex h-8 w-8 items-center justify-center rounded-lg text-ink-400 transition-colors hover:bg-ink-800 hover:text-ink-100"
              >
                <Icon name="zoom-out" className="h-4 w-4" />
              </button>
              <span className="w-12 text-center text-xs font-semibold tabular-nums text-ink-300">{Math.round(zoom * 100)}%</span>
              <button
                type="button"
                aria-label="Zoom in"
                onClick={() => setZoom((z) => Math.min(1.5, +(z + 0.1).toFixed(2)))}
                className="flex h-8 w-8 items-center justify-center rounded-lg text-ink-400 transition-colors hover:bg-ink-800 hover:text-ink-100"
              >
                <Icon name="zoom-in" className="h-4 w-4" />
              </button>
              <span className="mx-1.5 h-5 w-px bg-ink-700/70" />
              <button
                type="button"
                title="Random photo backdrop"
                aria-label="Random photo backdrop"
                onClick={randomBackdrop}
                className="flex h-8 w-8 items-center justify-center rounded-lg text-ink-400 transition-colors hover:bg-ink-800 hover:text-ember-400"
              >
                <Icon name="dice" className="h-4 w-4" />
              </button>
              <button
                type="button"
                title="Save picture of the card as displayed"
                aria-label="Save picture of the card as displayed"
                onClick={() => void handleSaveScene()}
                disabled={savingScene}
                className="flex h-8 w-8 items-center justify-center rounded-lg text-ink-400 transition-colors hover:bg-ink-800 hover:text-ember-400 disabled:cursor-wait disabled:opacity-50"
              >
                {savingScene ? (
                  <span className="h-4 w-4 animate-spin rounded-full border-2 border-ink-500 border-t-ember-400" />
                ) : (
                  <Icon name="camera" className="h-4 w-4" />
                )}
              </button>
            </div>
            <div className="hidden text-[11px] font-medium text-ink-500 sm:block">
              {dims.W} × {dims.H} px · exported at 3× ({dims.W * 3} × {dims.H * 3})
            </div>
          </div>

          <div className="slim-scroll relative flex flex-1 items-center justify-center overflow-auto p-8">
            <div
              className="shrink-0"
              style={{ width: dims.W * zoom, height: dims.H * zoom, perspective: scene ? "1400px" : undefined }}
            >
              <div
                style={
                  scene
                    ? { transform: `rotateX(11deg) rotateZ(${scene.tilt}deg)`, transformStyle: "preserve-3d", transition: "transform 0.3s ease" }
                    : undefined
                }
              >
                <div
                  key={`${data.orientation}-${style.id}-${data.orgMode}-${data.college}-${data.companyId}-${data.scene}`}
                  className="pop"
                >
                  <CardSvg
                    ref={svgRef}
                    model={model}
                    scale={zoom}
                    className={scene ? "drop-shadow-[0_16px_14px_rgba(0,0,0,0.8)]" : "drop-shadow-[0_28px_40px_rgba(0,0,0,0.5)]"}
                  />
                </div>
              </div>
            </div>
          </div>

          <div
            className={cn(
              "relative flex min-h-10 shrink-0 items-center justify-center gap-2 border-t border-ink-800/70 px-4 py-2 text-center text-[11px] font-medium text-ink-500",
              scene && "border-ink-800/40 bg-ink-950/70 backdrop-blur-sm"
            )}
          >
            <span className="h-1.5 w-1.5 shrink-0 rounded-full bg-ember-500" />
            <span className="truncate">
              {institution || "—"} · {LAYOUT_META[style.layout].name} · {style.palette.name}
              {data.customOn ? " (custom)" : ""} · {data.orientation}
              {scene ? ` · ${scene.name}` : ""} · {displayName || "No name yet — type one on the left"}
            </span>
          </div>
        </div>
      </main>

      {/* toast */}
      {toast && (
        <div
          key={toast.id}
          className="toast-in fixed bottom-6 left-1/2 z-50 flex items-center gap-2.5 rounded-xl bg-ink-100 py-2.5 pl-3.5 pr-4 text-[13px] font-semibold text-ink-950 shadow-2xl"
        >
          <span
            className={cn(
              "flex h-5 w-5 items-center justify-center rounded-full",
              toast.kind === "ok" ? "bg-emerald-500/20 text-emerald-700" : "bg-red-500/20 text-red-700"
            )}
          >
            <Icon name={toast.kind === "ok" ? "check" : "close"} className="h-3 w-3" strokeWidth={3} />
          </span>
          {toast.msg}
        </div>
      )}
    </div>
  );
}
