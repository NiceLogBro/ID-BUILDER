import type { IndustryId } from "../types";
import { industryFromText } from "./industries";
import { fetchDataUrl, trimLogo, type RealLogo } from "./logos";

/**
 * Live company research, run right in the browser against public, verifiable sources:
 *  1. Wikidata entity search + Wikipedia search (typo-tolerant, gives "did you mean" spellings)
 *  2. Wikidata Query Service — official name, description, HQ, industry, website, employees, founding year, logo file
 *  3. Wikimedia Commons — the official logo file; the company website's icon (via unavatar.io) as a fallback
 * Nothing is guessed: if no logo exists anywhere, the app's logo studio designs one instead.
 */

const WD_API = "https://www.wikidata.org/w/api.php";
const WP_API = "https://en.wikipedia.org/w/api.php";
const SPARQL = "https://query.wikidata.org/sparql";
const COMMONS_API = "https://commons.wikimedia.org/w/api.php";
const iconService = (domain: string) => `https://unavatar.io/${encodeURIComponent(domain)}?fallback=false`;

export interface OrgCandidate {
  qid: string;
  name: string;
  description: string;
  hq: string;
  country: string;
  industry: IndustryId;
  /** raw industry label from the records, e.g. "coffee" */
  industryLabel: string;
  website: string;
  employees: number;
  founded: string;
  ticker: string;
  sitelinks: number;
  logoFile: string | null;
  smallLogoFile: string | null;
}

export interface ResearchedOrg extends OrgCandidate {
  /** "r:Q37158" */
  id: string;
  logo: RealLogo | null;
  logoSource: "commons" | "website" | null;
  /** Commons file name or website domain the logo came from */
  logoNote: string;
  /** a small website icon kept as an extra option when it was too low-res to use by default */
  lowResIcon: RealLogo | null;
  researchedAt: number;
}

export type StepState = "running" | "done" | "warn" | "fail";
export interface ResearchStep {
  id: string;
  label: string;
  detail?: string;
  state: StepState;
}
export type OnStep = (s: ResearchStep) => void;

export interface ResearchResult {
  query: string;
  candidates: OrgCandidate[];
  /** spelling correction that was used ("Did you mean …") */
  suggestion: string | null;
  /** matches that were government / law-enforcement agencies (never offered) */
  blocked: number;
}

/* --------------------------------- helpers -------------------------------- */

async function getJson<T>(url: string, signal?: AbortSignal, timeoutMs = 12000): Promise<T> {
  const ctrl = new AbortController();
  const abort = () => ctrl.abort();
  if (signal) {
    if (signal.aborted) ctrl.abort();
    else signal.addEventListener("abort", abort, { once: true });
  }
  const timer = window.setTimeout(abort, timeoutMs);
  try {
    const res = await fetch(url, { signal: ctrl.signal });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return (await res.json()) as T;
  } finally {
    window.clearTimeout(timer);
    signal?.removeEventListener("abort", abort);
  }
}

const SUFFIX = /\b(the|inc|incorporated|corp|corporation|company|co|holdings?|group|plc|ltd|llc|lp|sa|ag|nv|gmbh)\b/g;

/** "The Walt Disney Company" → "walt disney" */
export function normOrg(s: string): string {
  return s
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/&/g, " and ")
    .replace(/['’.]/g, "")
    .replace(/[^a-z0-9 ]+/g, " ")
    .replace(SUFFIX, " ")
    .replace(/\s+/g, " ")
    .trim();
}

export function hostOf(url: string): string {
  try {
    return new URL(url).hostname.replace(/^www\./, "");
  } catch {
    return "";
  }
}

export const wikidataUrl = (qid: string) => `https://www.wikidata.org/wiki/${qid}`;
export const commonsPageUrl = (file: string) => `https://commons.wikimedia.org/wiki/File:${encodeURIComponent(file.replace(/ /g, "_"))}`;
/** Small preview for <img> tags (display only — it follows redirects, no CORS needed). */
export const commonsPreview = (file: string, w = 120) =>
  `https://commons.wikimedia.org/wiki/Special:FilePath/${encodeURIComponent(file.replace(/ /g, "_"))}?width=${w}`;

function fileOf(url: string): string | null {
  const i = url.indexOf("Special:FilePath/");
  if (i < 0) return null;
  try {
    return decodeURIComponent(url.slice(i + 17)).replace(/_/g, " ");
  } catch {
    return null;
  }
}

/** Prefer the current logo: skip "old/former" files, prefer SVG and the newest year in the file name. */
function pickLogo(files: string[]): string | null {
  const score = (n: string) => {
    let s = 0;
    if (/old|former|histor|retired|previous|vintage/i.test(n)) s += 5;
    if (!/\.svg$/i.test(n)) s += 1;
    const years = (n.match(/(?<!\d)(19|20)\d\d(?!\d)/g) ?? []).map(Number);
    if (years.length) s -= (Math.max(...years) - 1900) / 1000;
    return s;
  };
  return [...new Set(files)].sort((a, b) => score(a) - score(b) || a.localeCompare(b))[0] ?? null;
}

const GOV =
  /\b(government agency|government organi[sz]ation|federal agency|state agency|executive (branch|department)|law enforcement|police|sheriff|military|armed forces|army|navy|air force|marine corps|coast guard|intelligence agency|secret service|ministry|embassy|consulate|supreme court|legislature|parliament|national guard|border patrol|customs and border|immigration|homeland security|correctional|prison)\b/i;
const ORG =
  /compan|business|enterprise|corporat|organi[sz]ation|brand|conglomerate|bank|airline|retail|restaurant|chain|hospital|health system|nonprofit|non-profit|charit|foundation|startup|publisher|studio|developer|manufacturer|cooperative|firm|subsidiary|franchise|operator|association|institute|university|college|school|club|network|broadcaster|newspaper|insurer|utility|holding|store|supermarket|hotel|casino|carrier|laboratory|consult|website|online service|platform|marketplace|agency/i;
const NON =
  /\b(human|given name|family name|surname|disambiguation|taxon|species|genus|cultivar|film|album|single|song|episode|television series|book|novel|painting|city|town|village|municipality|county|river|lake|mountain|island|planet|asteroid|chemical|element|language|word|letter|fictional|character|year|month|award|ship|software version|protein|gene|dish|fruit|plant|animal)\b/i;

/* ---------------------------------- steps --------------------------------- */

interface WbSearch {
  search?: { id: string }[];
}
interface WpSearch {
  query?: { searchinfo?: { suggestion?: string }; search?: { title: string }[] };
}
interface WpProps {
  query?: { pages?: Record<string, { pageprops?: { wikibase_item?: string } }> };
}
interface SparqlRes {
  results: { bindings: Record<string, { value: string } | undefined>[] };
}

async function wikidataSearch(q: string, signal?: AbortSignal): Promise<string[]> {
  const j = await getJson<WbSearch>(
    `${WD_API}?action=wbsearchentities&format=json&origin=*&language=en&uselang=en&type=item&limit=10&search=${encodeURIComponent(q)}`,
    signal
  );
  return (j.search ?? []).map((s) => s.id).filter((id) => /^Q\d+$/.test(id));
}

async function wikipediaSearch(q: string, signal?: AbortSignal): Promise<{ titles: string[]; suggestion: string | null }> {
  const j = await getJson<WpSearch>(
    `${WP_API}?action=query&format=json&origin=*&list=search&srprop=&srlimit=6&srinfo=suggestion&srsearch=${encodeURIComponent(q)}`,
    signal
  );
  return { titles: (j.query?.search ?? []).map((s) => s.title), suggestion: j.query?.searchinfo?.suggestion ?? null };
}

async function wikipediaItems(titles: string[], signal?: AbortSignal): Promise<string[]> {
  if (!titles.length) return [];
  const j = await getJson<WpProps>(
    `${WP_API}?action=query&format=json&origin=*&prop=pageprops&ppprop=wikibase_item&redirects=1&titles=${encodeURIComponent(titles.join("|"))}`,
    signal
  );
  return Object.values(j.query?.pages ?? {})
    .map((p) => p.pageprops?.wikibase_item ?? "")
    .filter((id) => /^Q\d+$/.test(id));
}

function detailsQuery(ids: string[]): string {
  return `SELECT ?item (SAMPLE(?l) AS ?name) (SAMPLE(?d) AS ?desc) (GROUP_CONCAT(DISTINCT STR(?logo); separator="|") AS ?logos)
(SAMPLE(STR(?small)) AS ?smallLogo) (GROUP_CONCAT(DISTINCT STR(?site); separator=" ") AS ?websites) (SAMPLE(?hqL) AS ?hq) (SAMPLE(?cL) AS ?country)
(MAX(?emp) AS ?employees) (MIN(?inc) AS ?founded) (SAMPLE(?tick) AS ?ticker) (SAMPLE(?sl) AS ?sitelinks)
(GROUP_CONCAT(DISTINCT ?indL; separator="|") AS ?industries) (GROUP_CONCAT(DISTINCT ?tL; separator="|") AS ?types) (SAMPLE(?dis) AS ?dissolved)
WHERE {
  VALUES ?item { ${ids.map((i) => `wd:${i}`).join(" ")} }
  OPTIONAL { ?item rdfs:label ?l FILTER(LANG(?l) = "en") }
  OPTIONAL { ?item schema:description ?d FILTER(LANG(?d) = "en") }
  OPTIONAL { ?item wdt:P154 ?logo }
  OPTIONAL { ?item wdt:P8972 ?small }
  OPTIONAL { ?item wdt:P856 ?site }
  OPTIONAL { ?item wdt:P159 ?hqI . ?hqI rdfs:label ?hqL FILTER(LANG(?hqL) = "en") }
  OPTIONAL { ?item wdt:P17 ?cI . ?cI rdfs:label ?cL FILTER(LANG(?cL) = "en") }
  OPTIONAL { ?item wdt:P1128 ?emp }
  OPTIONAL { ?item wdt:P571 ?inc }
  OPTIONAL { ?item wdt:P249 ?tick }
  OPTIONAL { ?item wdt:P576 ?dis }
  OPTIONAL { ?item wikibase:sitelinks ?sl }
  OPTIONAL { ?item wdt:P452 ?indI . ?indI rdfs:label ?indL FILTER(LANG(?indL) = "en") }
  OPTIONAL { ?item wdt:P31 ?tI . ?tI rdfs:label ?tL FILTER(LANG(?tL) = "en") }
} GROUP BY ?item`;
}

/** Several official websites on record? Prefer the main .com, then .org/.net, then the shortest domain. */
function pickSite(list: string): string {
  const rank = (u: string) => {
    const h = hostOf(u);
    return (/\.com$/.test(h) ? 0 : /\.(org|net|us)$/.test(h) ? 1 : 2) * 100 + h.length;
  };
  return list
    .split(" ")
    .filter((u) => /^https?:\/\//.test(u))
    .sort((a, b) => rank(a) - rank(b))[0] ?? "";
}

interface Parsed {
  cand: OrgCandidate;
  types: string;
  industries: string;
  dissolved: boolean;
}

async function fetchDetails(ids: string[], signal?: AbortSignal): Promise<Parsed[]> {
  const j = await getJson<SparqlRes>(`${SPARQL}?format=json&query=${encodeURIComponent(detailsQuery(ids))}`, signal, 20000);
  const v = (b: Record<string, { value: string } | undefined>, k: string) => b[k]?.value ?? "";
  return j.results.bindings.map((b) => {
    const qid = v(b, "item").split("/").pop() ?? "";
    const industries = v(b, "industries");
    const types = v(b, "types");
    const desc = v(b, "desc");
    const logoFiles = v(b, "logos")
      .split("|")
      .map(fileOf)
      .filter((f): f is string => !!f);
    const firstInd = industries.split("|").filter(Boolean)[0] ?? "";
    return {
      types,
      industries,
      dissolved: !!v(b, "dissolved"),
      cand: {
        qid,
        name: v(b, "name") || qid,
        description: desc,
        hq: v(b, "hq"),
        country: v(b, "country"),
        industry: industryFromText(industries) ?? industryFromText(types) ?? industryFromText(desc) ?? "general",
        industryLabel: firstInd.replace(/\s+industry$/i, ""),
        website: pickSite(v(b, "websites")),
        employees: Math.round(Number(v(b, "employees")) || 0),
        founded: (/^(\d{3,4})-/.exec(v(b, "founded")) ?? [])[1] ?? "",
        ticker: v(b, "ticker"),
        sitelinks: Number(v(b, "sitelinks")) || 0,
        logoFile: pickLogo(logoFiles),
        smallLogoFile: fileOf(v(b, "smallLogo")),
      },
    };
  });
}

/* ----------------------------- organization search ----------------------------- */

const resultCache = new Map<string, ResearchResult>();

/** Find real organizations matching a typed name (typos are corrected via Wikipedia's spelling suggestions). */
export async function researchOrganizations(query: string, onStep: OnStep, signal?: AbortSignal): Promise<ResearchResult> {
  const q = query.trim();
  const key = normOrg(q) || q.toLowerCase();
  const hit = resultCache.get(key);
  if (hit) {
    onStep({ id: "search", label: `Searched public records for “${q}”`, detail: "saved from an earlier lookup", state: "done" });
    onStep({
      id: "records",
      label: hit.candidates.length ? `Found ${hit.candidates.length} real organization${hit.candidates.length === 1 ? "" : "s"}` : "No matching organizations",
      state: hit.candidates.length ? "done" : "warn",
    });
    return hit;
  }

  onStep({ id: "search", label: `Searching Wikidata & Wikipedia for “${q}”`, state: "running" });
  const [wd, wp] = await Promise.allSettled([wikidataSearch(q, signal), wikipediaSearch(q, signal)]);
  if (signal?.aborted) throw new DOMException("aborted", "AbortError");
  if (wd.status === "rejected" && wp.status === "rejected") {
    onStep({ id: "search", label: "Couldn’t reach the research sources", detail: "check your connection", state: "fail" });
    throw new Error("offline");
  }
  let ids = wd.status === "fulfilled" ? wd.value : [];
  const wpv = wp.status === "fulfilled" ? wp.value : { titles: [], suggestion: null };
  const suggestion = wpv.suggestion && normOrg(wpv.suggestion) !== normOrg(q) ? wpv.suggestion : null;
  onStep({
    id: "search",
    label: `Searched Wikidata & Wikipedia for “${q}”`,
    detail: `${ids.length} knowledge-graph match${ids.length === 1 ? "" : "es"}`,
    state: "done",
  });

  if (suggestion || ids.length < 4) {
    onStep({ id: "spell", label: suggestion ? `Checking the spelling “${suggestion}”` : "Cross-checking Wikipedia articles", state: "running" });
    const [s2, wpi] = await Promise.allSettled([
      suggestion ? wikidataSearch(suggestion, signal) : Promise.resolve<string[]>([]),
      wikipediaItems(wpv.titles, signal),
    ]);
    const extra = [...(s2.status === "fulfilled" ? s2.value : []), ...(wpi.status === "fulfilled" ? wpi.value : [])];
    ids = [...new Set([...ids, ...extra])];
    onStep({
      id: "spell",
      label: suggestion ? `Did you mean “${suggestion}”?` : "Cross-checked Wikipedia articles",
      detail: `${extra.length} more candidate${extra.length === 1 ? "" : "s"}`,
      state: "done",
    });
  }
  if (signal?.aborted) throw new DOMException("aborted", "AbortError");

  ids = ids.slice(0, 16);
  if (!ids.length) {
    onStep({ id: "records", label: "No public records found", detail: "nothing by that name in the knowledge graph", state: "warn" });
    const empty: ResearchResult = { query: q, candidates: [], suggestion, blocked: 0 };
    resultCache.set(key, empty);
    return empty;
  }

  onStep({ id: "records", label: `Reading official records for ${ids.length} matches`, state: "running" });
  let parsed: Parsed[];
  try {
    parsed = await fetchDetails(ids, signal);
  } catch (e) {
    if (signal?.aborted) throw e;
    onStep({ id: "records", label: "Couldn’t read the official records", detail: "the records service didn’t answer", state: "fail" });
    throw e;
  }

  const nq = normOrg(q);
  const ns = suggestion ? normOrg(suggestion) : "";
  let blocked = 0;
  const scored: { c: OrgCandidate; score: number }[] = [];
  for (const p of parsed) {
    const c = p.cand;
    const text = `${p.types} ${c.description}`;
    if (GOV.test(text)) {
      blocked++;
      continue;
    }
    const signals = (p.industries ? 1 : 0) + (c.employees ? 1 : 0) + (c.ticker ? 1 : 0) + (c.hq ? 1 : 0) + (c.website ? 1 : 0);
    const orgish = ORG.test(text);
    if (p.dissolved) continue;
    if (NON.test(p.types) && !orgish) continue;
    if (!orgish && signals < 2) continue;
    const nn = normOrg(c.name);
    let score = 0;
    if (nn === nq || (ns && nn === ns)) score += 1000;
    else if ((nq && nn.startsWith(nq)) || (ns && nn.startsWith(ns))) score += 300;
    else if (nq && nn.includes(nq)) score += 120;
    score += Math.log10(1 + c.sitelinks) * 80 + (c.logoFile || c.smallLogoFile ? 60 : 0) + signals * 8;
    scored.push({ c, score });
  }
  const candidates = scored
    .sort((a, b) => b.score - a.score)
    .slice(0, 6)
    .map((x) => x.c);
  const withLogo = candidates.filter((c) => c.logoFile || c.smallLogoFile).length;
  onStep({
    id: "records",
    label: candidates.length
      ? `Found ${candidates.length} real organization${candidates.length === 1 ? "" : "s"}`
      : "No matching organizations",
    detail: candidates.length
      ? `${withLogo} with an official logo on file`
      : blocked
        ? "only government agencies matched — those aren’t offered"
        : "only people, places or products matched",
    state: candidates.length ? "done" : "warn",
  });

  const result: ResearchResult = { query: q, candidates, suggestion, blocked };
  if (resultCache.size > 80) resultCache.clear();
  resultCache.set(key, result);
  return result;
}

/** Re-read one organization's records (used by "Refresh research"). */
export async function researchById(qid: string, onStep: OnStep, signal?: AbortSignal): Promise<OrgCandidate | null> {
  onStep({ id: "records", label: "Re-reading the official records", detail: qid, state: "running" });
  const parsed = await fetchDetails([qid], signal);
  const c = parsed[0]?.cand ?? null;
  onStep({ id: "records", label: c ? "Official records updated" : "Records not found", detail: qid, state: c ? "done" : "warn" });
  return c;
}

/* ---------------------------------- logos ---------------------------------- */

interface CommonsInfo {
  query?: { pages?: Record<string, { imageinfo?: { thumburl?: string; url?: string }[] }> };
}

async function commonsThumb(file: string, signal?: AbortSignal): Promise<string> {
  const j = await getJson<CommonsInfo>(
    `${COMMONS_API}?action=query&format=json&origin=*&prop=imageinfo&iiprop=url&iiurlwidth=250&titles=${encodeURIComponent(`File:${file}`)}`,
    signal
  );
  const ii = Object.values(j.query?.pages ?? {})[0]?.imageinfo?.[0];
  const u = ii?.thumburl || ii?.url;
  if (!u) throw new Error("file not found");
  return u;
}

/** Find the organization's real logo: official file on Commons → website icon → none (the studio designs one). */
export async function researchLogo(
  c: OrgCandidate,
  onStep: OnStep,
  signal?: AbortSignal
): Promise<Pick<ResearchedOrg, "logo" | "logoSource" | "logoNote" | "lowResIcon">> {
  const files = [...new Set([c.logoFile, c.smallLogoFile].filter((f): f is string => !!f))];
  for (const f of files) {
    onStep({ id: "logo", label: "Downloading the official logo from Wikimedia Commons", detail: f, state: "running" });
    try {
      const logo = await trimLogo(await fetchDataUrl(await commonsThumb(f, signal), signal));
      onStep({ id: "logo", label: "Official logo found on Wikimedia Commons", detail: f, state: "done" });
      return { logo, logoSource: "commons", logoNote: f, lowResIcon: null };
    } catch (e) {
      if (signal?.aborted) throw e;
      onStep({ id: "logo", label: "Couldn’t download the logo file", detail: f, state: "warn" });
    }
  }
  if (!files.length) onStep({ id: "logo", label: "No logo file in the official records", state: "warn" });

  let lowResIcon: RealLogo | null = null;
  const domain = hostOf(c.website);
  if (domain) {
    onStep({ id: "icon", label: `Checking ${domain} for a brand icon`, state: "running" });
    try {
      const logo = await trimLogo(await fetchDataUrl(iconService(domain), signal));
      if ((logo.px ?? 0) >= 64) {
        onStep({ id: "icon", label: `Brand icon found on ${domain}`, detail: `${logo.px}px`, state: "done" });
        return { logo, logoSource: "website", logoNote: domain, lowResIcon: null };
      }
      lowResIcon = logo;
      onStep({ id: "icon", label: `Only a small icon on ${domain}`, detail: `${logo.px}px — kept as an extra option`, state: "warn" });
    } catch (e) {
      if (signal?.aborted) throw e;
      onStep({ id: "icon", label: `No brand icon found on ${domain}`, state: "warn" });
    }
  }
  onStep({ id: "design", label: "No usable logo found — the logo studio designed one", state: "done" });
  return { logo: null, logoSource: null, logoNote: "", lowResIcon };
}

/* ---------------------------------- store ---------------------------------- */

const STORE = "badgesmith:researched:v1";
const MAX_SAVED = 24;

function validLogo(l: unknown): l is RealLogo {
  const x = l as RealLogo | null;
  return !!x && typeof x.url === "string" && x.url.startsWith("data:image/") && typeof x.aspect === "number";
}

export function loadResearched(): ResearchedOrg[] {
  try {
    const a = JSON.parse(localStorage.getItem(STORE) || "[]") as ResearchedOrg[];
    if (!Array.isArray(a)) return [];
    return a
      .filter((r) => r && typeof r.id === "string" && r.id.startsWith("r:Q") && typeof r.name === "string")
      .map((r) => ({
        ...r,
        logo: validLogo(r.logo) ? r.logo : null,
        lowResIcon: validLogo(r.lowResIcon) ? r.lowResIcon : null,
      }))
      .slice(0, MAX_SAVED);
  } catch {
    return [];
  }
}

export function saveResearched(list: ResearchedOrg[]) {
  try {
    localStorage.setItem(STORE, JSON.stringify(list.slice(0, MAX_SAVED)));
  } catch {
    try {
      localStorage.setItem(STORE, JSON.stringify(list.slice(0, 6)));
    } catch {
      /* storage full — researched orgs just won't persist */
    }
  }
}
