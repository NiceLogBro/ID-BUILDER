import type { IndustryId, OrgMode, Role } from "../types";

export const INDUSTRIES: { id: IndustryId; name: string }[] = [
  { id: "technology", name: "Technology" },
  { id: "finance", name: "Finance & Insurance" },
  { id: "healthcare", name: "Healthcare" },
  { id: "retail", name: "Retail & Consumer" },
  { id: "food", name: "Food & Beverage" },
  { id: "energy", name: "Energy & Utilities" },
  { id: "manufacturing", name: "Industrial & Manufacturing" },
  { id: "transportation", name: "Transportation & Logistics" },
  { id: "automotive", name: "Automotive" },
  { id: "aerospace", name: "Aerospace & Defense" },
  { id: "media", name: "Media & Entertainment" },
  { id: "hospitality", name: "Hospitality & Travel" },
  { id: "construction", name: "Real Estate & Construction" },
  { id: "professional", name: "Professional Services" },
  { id: "education", name: "Education" },
  { id: "nonprofit", name: "Nonprofit" },
  { id: "general", name: "General business" },
];

export const INDUSTRY_IDS: IndustryId[] = INDUSTRIES.map((i) => i.id);
export const INDUSTRY_NAME = Object.fromEntries(INDUSTRIES.map((i) => [i.id, i.name])) as Record<IndustryId, string>;

export function isIndustry(v: unknown): v is IndustryId {
  return typeof v === "string" && (INDUSTRY_IDS as string[]).includes(v);
}

const KEYWORDS: [RegExp, IndustryId][] = [
  [/hospital|health|medical|pharma|biotech|clinic|nursing|dental|life science/, "healthcare"],
  [/aerospace|defen[cs]e|spacecraft|rocket|satellite/, "aerospace"],
  [/airline|aviation|railroad|railway|logistics|shipping|trucking|freight|transport|courier|parcel|delivery/, "transportation"],
  [/automotive|automobile|vehicle|car manufactur|motorcycle/, "automotive"],
  [/bank|financ|insurance|invest|asset management|credit|payment|brokerage|mortgage|accounting|fintech/, "finance"],
  [/video game|media|entertainment|film|television|broadcast|publishing|newspaper|music|advertising|radio|streaming/, "media"],
  [/software|internet|computer|semiconductor|telecom|information technology|electronics|cloud|technology|artificial intelligence/, "technology"],
  [/oil|petroleum|natural gas|energy|electric util|utilit|power station|nuclear|solar|coal|renewable/, "energy"],
  [
    /restaurant|food|beverage|brew|drink|grocery|agricultur|meat|dairy|bakery|coffee|café|cafe|fast food|ice cream|confection|candy|chocolate|snack|winery|wine|distill|cereal|juice|soft drink|\btea\b/,
    "food",
  ],
  [/retail|supermarket|department store|store|e-commerce|apparel|clothing|fashion|consumer goods|cosmetic|footwear/, "retail"],
  [/hotel|hospitality|casino|travel|tourism|cruise|theme park|resort|leisure/, "hospitality"],
  [/construction|engineering|real estate|architecture|building|homebuild|property/, "construction"],
  [/consult|law firm|legal|professional services|staffing|human resources|auditing/, "professional"],
  [/education|school|university|college|e-learning|edtech/, "education"],
  [/chemical|steel|manufactur|industrial|machinery|mining|metal|paper|packaging|conglomerate/, "manufacturing"],
  [/nonprofit|non-profit|charity|charitable|foundation|association|society|humanitarian/, "nonprofit"],
];

/** Best-guess industry from free text such as Wikidata industry labels or a description. */
export function industryFromText(...texts: (string | null | undefined)[]): IndustryId | null {
  const t = texts.filter(Boolean).join(" ").toLowerCase();
  if (!t.trim()) return null;
  for (const [rx, id] of KEYWORDS) if (rx.test(t)) return id;
  return null;
}

const SUGGEST: Record<IndustryId, { titles: string[]; depts: string[] }> = {
  technology: { titles: ["Software Engineer", "Product Manager", "Data Scientist", "UX Designer"], depts: ["Engineering", "Product", "Design", "IT"] },
  finance: { titles: ["Financial Analyst", "Relationship Manager", "Risk Analyst", "Accountant"], depts: ["Finance", "Risk & Compliance", "Wealth Management", "Operations"] },
  healthcare: { titles: ["Registered Nurse", "Physician", "Medical Assistant", "Pharmacist"], depts: ["Nursing", "Emergency", "Pharmacy", "Radiology"] },
  retail: { titles: ["Store Associate", "Store Manager", "Merchandiser", "Visual Designer"], depts: ["Store Operations", "Merchandising", "Customer Service", "Supply Chain"] },
  food: { titles: ["Shift Lead", "Food Scientist", "Brand Manager", "Line Cook"], depts: ["Operations", "R&D", "Marketing", "Kitchen"] },
  energy: { titles: ["Field Engineer", "Plant Operator", "Lineworker", "Geologist"], depts: ["Operations", "Engineering", "Grid Services", "Safety"] },
  manufacturing: { titles: ["Process Engineer", "Machine Operator", "Quality Inspector", "Plant Manager"], depts: ["Production", "Quality", "Engineering", "Logistics"] },
  transportation: { titles: ["Logistics Coordinator", "Driver", "Dispatcher", "Pilot"], depts: ["Logistics", "Fleet", "Operations", "Safety"] },
  automotive: { titles: ["Design Engineer", "Technician", "Assembly Lead", "Test Driver"], depts: ["Engineering", "Manufacturing", "Design", "Service"] },
  aerospace: { titles: ["Aerospace Engineer", "Avionics Technician", "Systems Engineer", "Test Pilot"], depts: ["Engineering", "Flight Test", "Mission Systems", "Quality"] },
  media: { titles: ["Producer", "Editor", "Content Strategist", "Journalist"], depts: ["Production", "Editorial", "Marketing", "Creative"] },
  hospitality: { titles: ["Front Desk Agent", "Event Coordinator", "Concierge", "Chef"], depts: ["Guest Services", "Events", "Housekeeping", "Food & Beverage"] },
  construction: { titles: ["Project Manager", "Site Engineer", "Architect", "Estimator"], depts: ["Projects", "Design", "Field Operations", "Leasing"] },
  professional: { titles: ["Consultant", "Associate", "Paralegal", "Auditor"], depts: ["Advisory", "Legal", "Audit", "Strategy"] },
  education: { titles: ["Teacher", "Program Coordinator", "Librarian", "Counselor"], depts: ["Academics", "Student Services", "Library", "Admissions"] },
  nonprofit: { titles: ["Program Manager", "Volunteer Coordinator", "Grant Writer", "Outreach Lead"], depts: ["Programs", "Development", "Community", "Volunteers"] },
  general: { titles: ["Associate", "Coordinator", "Manager", "Specialist"], depts: ["Operations", "Administration", "Sales", "Marketing"] },
};

const UNIVERSITY: Record<Role, { titles: string[]; depts: string[] }> = {
  student: { titles: ["Computer Science", "Biology", "Economics", "Psychology"], depts: ["Engineering", "Arts & Sciences", "Business", "Medicine"] },
  intern: { titles: ["Research Intern", "Lab Assistant", "Teaching Assistant", "Admissions Intern"], depts: ["Research", "Library", "IT Services", "Athletics"] },
  staff: { titles: ["Program Coordinator", "Professor", "Research Scientist", "Academic Advisor"], depts: ["Admissions", "Registrar", "Research", "Student Life"] },
};

/** One-tap title / department ideas that fit the organization type, industry and role. */
export function suggestionsFor(mode: OrgMode, industry: IndustryId, role: Role): { titles: string[]; depts: string[] } {
  if (mode === "university") return UNIVERSITY[role];
  const base = SUGGEST[industry] ?? SUGGEST.general;
  if (role === "intern") return { titles: base.titles.slice(0, 3).map((t) => `${t} Intern`), depts: base.depts };
  if (role === "student") return { titles: ["Student Worker", "Co-op Student", "Apprentice"], depts: base.depts };
  return base;
}
