import { COMMONS_BASE, COMMONS_LOGOS } from "../data/logoMap";
import { COMPANY_COMMONS_LOGOS } from "../data/companyLogoMap";
import { UNI_LOGOS } from "../data/assets/uniLogos";
import { COMPANY_LOGOS } from "../data/assets/companyLogos";

/**
 * Real logos for universities and companies. The most prominent ones are bundled (as text modules, so they
 * work offline); every other known logo is fetched on demand from Wikimedia Commons (CORS-enabled) and cached.
 */
export const bundledLogoUrl = (id: string): string | null => UNI_LOGOS[id] ?? null;
export const hasRealLogo = (id: string): boolean => id in UNI_LOGOS || id in COMMONS_LOGOS;
export const REAL_LOGO_COUNT = new Set([...Object.keys(UNI_LOGOS), ...Object.keys(COMMONS_LOGOS)]).size;

export const bundledCompanyLogoUrl = (id: string): string | null => COMPANY_LOGOS[id] ?? null;
export const hasCompanyLogo = (id: string): boolean => id in COMPANY_LOGOS || id in COMPANY_COMMONS_LOGOS;
export const COMPANY_LOGO_COUNT = new Set([...Object.keys(COMPANY_LOGOS), ...Object.keys(COMPANY_COMMONS_LOGOS)]).size;

export interface RealLogo {
  /** trimmed PNG data URL (safe to embed in the exported card) */
  url: string;
  /** width / height after trimming empty margins */
  aspect: number;
  /** mostly-white artwork meant for dark backgrounds */
  dark: boolean;
  /** the logo's dominant brand color, or null when it can't be told */
  brand: string | null;
  /** size of the artwork in source pixels (longest side, after trimming) — used to reject tiny icons */
  px?: number;
}

export type RealResult = { status: "found"; logo: RealLogo } | { status: "none" } | { status: "error" };

function blobToDataUrl(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(r.result as string);
    r.onerror = reject;
    r.readAsDataURL(blob);
  });
}

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error("image failed to decode"));
    img.src = src;
  });
}

/** Download an image (CORS) and return it as a data URL, so it can be embedded in the exported card. */
export async function fetchDataUrl(src: string, signal?: AbortSignal, timeoutMs = 12000): Promise<string> {
  if (src.startsWith("data:")) return src;
  const ctrl = new AbortController();
  const abort = () => ctrl.abort();
  if (signal) {
    if (signal.aborted) ctrl.abort();
    else signal.addEventListener("abort", abort, { once: true });
  }
  const timer = window.setTimeout(abort, timeoutMs);
  try {
    const res = await fetch(src, { signal: ctrl.signal, mode: "cors" });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const blob = await res.blob();
    if (!blob.type.startsWith("image/")) throw new Error("not an image");
    return await blobToDataUrl(blob);
  } finally {
    window.clearTimeout(timer);
    signal?.removeEventListener("abort", abort);
  }
}

const toDataUrl = (src: string) => fetchDataUrl(src, undefined, 9000);

/** Most common saturated color in the artwork (near-black for monochrome logos). */
function brandColor(data: Uint8ClampedArray): string | null {
  const buckets = new Map<number, [number, number, number, number]>();
  let dark = 0;
  let total = 0;
  for (let i = 0; i < data.length; i += 8) {
    if (data[i + 3] < 128) continue;
    const r = data[i];
    const g = data[i + 1];
    const b = data[i + 2];
    total++;
    const max = Math.max(r, g, b);
    const min = Math.min(r, g, b);
    if (max < 70) {
      dark++;
      continue;
    }
    if (min > 225 || max - min < 40) continue;
    const key = ((r >> 5) << 6) | ((g >> 5) << 3) | (b >> 5);
    const e = buckets.get(key) ?? [0, 0, 0, 0];
    e[0]++;
    e[1] += r;
    e[2] += g;
    e[3] += b;
    buckets.set(key, e);
  }
  let best: [number, number, number, number] | null = null;
  for (const e of buckets.values()) if (!best || e[0] > best[0]) best = e;
  if (best && best[0] >= Math.max(8, total * 0.02)) {
    const hex = (v: number) => Math.round(v).toString(16).padStart(2, "0");
    return `#${hex(best[1] / best[0])}${hex(best[2] / best[0])}${hex(best[3] / best[0])}`;
  }
  if (total && dark / total > 0.3) return "#15181d";
  return null;
}

/** Crop away transparent / white margins so the logo fills its frame, and measure its aspect ratio. */
export async function trimLogo(dataUrl: string): Promise<RealLogo> {
  const img = await loadImage(dataUrl);
  const w = img.naturalWidth;
  const h = img.naturalHeight;
  if (!w || !h) throw new Error("empty image");
  const c = document.createElement("canvas");
  c.width = w;
  c.height = h;
  const ctx = c.getContext("2d", { willReadFrequently: true });
  if (!ctx) throw new Error("no canvas");
  ctx.drawImage(img, 0, 0);
  const { data } = ctx.getImageData(0, 0, w, h);

  let opaque = 0;
  let light = 0;
  for (let i = 0; i < data.length; i += 4) {
    if (data[i + 3] < 28) continue;
    opaque++;
    if (data[i] > 238 && data[i + 1] > 238 && data[i + 2] > 238) light++;
  }
  const hasAlpha = opaque < w * h * 0.92;
  const dark = hasAlpha && opaque > 0 && light / opaque > 0.92;

  let minX = w;
  let minY = h;
  let maxX = -1;
  let maxY = -1;
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const i = (y * w + x) * 4;
      if (data[i + 3] < 28) continue;
      if (!dark && data[i] > 238 && data[i + 1] > 238 && data[i + 2] > 238) continue;
      if (x < minX) minX = x;
      if (x > maxX) maxX = x;
      if (y < minY) minY = y;
      if (y > maxY) maxY = y;
    }
  }
  if (maxX < 0) {
    minX = 0;
    minY = 0;
    maxX = w - 1;
    maxY = h - 1;
  }
  minX = Math.max(0, minX - 1);
  minY = Math.max(0, minY - 1);
  maxX = Math.min(w - 1, maxX + 1);
  maxY = Math.min(h - 1, maxY + 1);
  const cw = maxX - minX + 1;
  const ch = maxY - minY + 1;

  const sc = Math.min(1, 300 / Math.max(cw, ch));
  const out = document.createElement("canvas");
  out.width = Math.max(1, Math.round(cw * sc));
  out.height = Math.max(1, Math.round(ch * sc));
  const octx = out.getContext("2d");
  if (!octx) throw new Error("no canvas");
  octx.imageSmoothingQuality = "high";
  octx.drawImage(c, minX, minY, cw, ch, 0, 0, out.width, out.height);
  return {
    url: out.toDataURL("image/png"),
    aspect: Math.min(6, Math.max(0.3, cw / ch)),
    dark,
    brand: dark ? null : brandColor(data),
    px: Math.max(cw, ch),
  };
}

/** thumb/a/ab/Name.png/250px-Name.png → a/ab/Name.png (SVGs have no usable original, so null). */
function originalOf(path: string): string | null {
  if (!path.startsWith("thumb/")) return null;
  const parts = path.slice(6).split("/");
  parts.pop();
  const rel = parts.join("/");
  return /\.svg$/i.test(rel) ? null : rel;
}

const cache = new Map<string, Promise<RealResult>>();

function load(key: string, bundled: string | null, remote: string | undefined): Promise<RealResult> {
  let p = cache.get(key);
  if (!p) {
    p = (async (): Promise<RealResult> => {
      if (!bundled && !remote) return { status: "none" };
      const tryLoad = async (src: string): Promise<RealLogo> => trimLogo(await toDataUrl(src));
      try {
        return { status: "found", logo: await tryLoad(bundled ?? COMMONS_BASE + remote) };
      } catch {
        // Small raster logos have no 250px rendition — fall back to the original file.
        const orig = !bundled && remote ? originalOf(remote) : null;
        if (orig) {
          try {
            return { status: "found", logo: await tryLoad(COMMONS_BASE + orig) };
          } catch {
            /* fall through */
          }
        }
        return { status: "error" };
      }
    })();
    cache.set(key, p);
    // never cache a failure (the user may just have been offline)
    void p.then((r) => {
      if (r.status === "error") cache.delete(key);
    });
  }
  return p;
}

export const loadRealLogo = (id: string) => load(`u:${id}`, UNI_LOGOS[id] ?? null, COMMONS_LOGOS[id]);
export const loadCompanyLogo = (id: string) => load(`c:${id}`, COMPANY_LOGOS[id] ?? null, COMPANY_COMMONS_LOGOS[id]);
