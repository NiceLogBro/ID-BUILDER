import { fontCssForExport } from "./fonts";

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error("Could not render the card"));
    img.src = src;
  });
}

/** Serialize the live card <svg> (with fonts embedded) into a raster image of the given pixel size. */
async function svgToImage(svg: SVGSVGElement, pixelW: number, pixelH: number): Promise<HTMLImageElement> {
  const NS = "http://www.w3.org/2000/svg";
  const clone = svg.cloneNode(true) as SVGSVGElement;
  clone.setAttribute("xmlns", NS);
  clone.setAttribute("width", String(Math.round(pixelW)));
  clone.setAttribute("height", String(Math.round(pixelH)));
  clone.removeAttribute("class");
  clone.removeAttribute("style");

  const css = await fontCssForExport();
  if (css) {
    const style = document.createElementNS(NS, "style");
    style.textContent = css;
    clone.insertBefore(style, clone.firstChild);
  }

  const xml = new XMLSerializer().serializeToString(clone);
  const img = await loadImage("data:image/svg+xml;charset=utf-8," + encodeURIComponent(xml));
  // Give the browser a beat to finish decoding the embedded fonts before we paint.
  await new Promise((r) => setTimeout(r, 60));
  return img;
}

function saveBlob(blob: Blob, fileName: string) {
  const a = document.createElement("a");
  a.download = fileName;
  a.href = URL.createObjectURL(blob);
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 4000);
}

/**
 * Rasterize the live card <svg> to a PNG. The preview and the export are literally the same
 * SVG, so what you see is exactly what you download. Fonts are embedded into the SVG first.
 */
export async function exportSvgAsPng(
  svg: SVGSVGElement,
  W: number,
  H: number,
  fileName: string,
  scale = 3
): Promise<void> {
  const img = await svgToImage(svg, W * scale, H * scale);

  const canvas = document.createElement("canvas");
  canvas.width = W * scale;
  canvas.height = H * scale;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Canvas unavailable");
  // Draw twice: some browsers finish decoding the embedded fonts only after the first paint.
  ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
  await new Promise((r) => setTimeout(r, 60));
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

  const blob = await new Promise<Blob | null>((res) => canvas.toBlob(res, "image/png"));
  if (!blob) throw new Error("PNG encoding failed");
  saveBlob(blob, fileName);
}

export interface SceneShot {
  svg: SVGSVGElement;
  cardW: number;
  cardH: number;
  /** backdrop photo (bundled data URL) — null renders the dark studio background */
  backdropSrc: string | null;
  tiltDeg: number;
  fileName: string;
}

/**
 * Save a photo-realistic picture of the card lying on the surface: ultra-dark
 * cinematic grade with a heavy vignette, the card drawn large and close up with
 * a photographic keystone (top edge slightly narrower, as seen from above) and
 * a tight contact shadow taken from the card's own silhouette.
 */
export async function exportSceneAsPng(o: SceneShot): Promise<void> {
  const W = 1600;
  const H = 1000;
  const canvas = document.createElement("canvas");
  canvas.width = W;
  canvas.height = H;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Canvas unavailable");

  if (o.backdropSrc) {
    const bg = await loadImage(o.backdropSrc);
    const bw = bg.naturalWidth || W;
    const bh = bg.naturalHeight || H;
    const s = Math.max(W / bw, H / bh);
    const dw = bw * s;
    const dh = bh * s;
    ctx.drawImage(bg, (W - dw) / 2, (H - dh) / 2, dw, dh);
  } else {
    const g = ctx.createRadialGradient(W / 2, H / 2, 100, W / 2, H / 2, W * 0.7);
    g.addColorStop(0, "#1b1f26");
    g.addColorStop(1, "#0b0d11");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, W, H);
  }

  // Ultra-dark grade: crush the backdrop, then a heavy vignette.
  ctx.fillStyle = "rgba(3,5,9,0.45)";
  ctx.fillRect(0, 0, W, H);
  const v = ctx.createRadialGradient(
    W / 2, H * 0.46, Math.min(W, H) * 0.26,
    W / 2, H * 0.46, Math.max(W, H) * 0.72
  );
  v.addColorStop(0, "rgba(0,0,0,0)");
  v.addColorStop(1, "rgba(0,0,0,0.66)");
  ctx.fillStyle = v;
  ctx.fillRect(0, 0, W, H);

  // Close up: the card fills most of the frame.
  const scale = Math.min((W * 0.66) / o.cardW, (H * 0.86) / o.cardH);
  const cw = Math.round(o.cardW * scale);
  const ch = Math.round(o.cardH * scale);
  const card = await svgToImage(o.svg, cw, ch);

  // Compose card + contact shadow offscreen so the whole thing can tilt as one.
  const pad = Math.round(ch * 0.14);
  const off = document.createElement("canvas");
  off.width = cw + pad * 2;
  off.height = ch + pad * 2;
  const octx = off.getContext("2d");
  if (!octx) throw new Error("Canvas unavailable");

  // Tight contact shadow from the card's own silhouette, hugging its bottom edge.
  octx.save();
  try {
    octx.filter = `blur(${Math.max(6, Math.round(ch * 0.03))}px) brightness(0)`;
  } catch {
    /* older canvas — shadow just renders unblurred */
  }
  octx.globalAlpha = 0.68;
  octx.drawImage(card, pad, pad + Math.round(ch * 0.045), cw, ch);
  octx.restore();

  // Keystone: draw the card in thin horizontal slices, top edge ~93% of bottom width.
  const N = 56;
  for (let j = 0; j < N; j++) {
    const t0 = j / N;
    const tm = (j + 0.5) / N;
    const w = cw * (0.93 + 0.07 * tm);
    const sh = ch / N + 0.6;
    octx.drawImage(card, 0, t0 * ch, cw, sh, pad + (cw - w) / 2, pad + t0 * ch, w, sh);
  }

  ctx.save();
  ctx.translate(W / 2, H * 0.52);
  ctx.rotate((o.tiltDeg * Math.PI) / 180);
  ctx.drawImage(off, -off.width / 2, -off.height / 2);
  ctx.restore();

  const blob = await new Promise<Blob | null>((res) => canvas.toBlob(res, "image/png"));
  if (!blob) throw new Error("PNG encoding failed");
  saveBlob(blob, o.fileName);
}
