import { RAW_INSTITUTIONS } from "../data/institutions";
import { crestDataUrl } from "./crest";
import { bundledLogoUrl, type RealLogo } from "./logos";
import mit1 from "../assets/logos/mit-1.jpg";
import mit2 from "../assets/logos/mit-2.jpg";
import stanford1 from "../assets/logos/stanford-1.jpg";
import stanford2 from "../assets/logos/stanford-2.jpg";
import harvard1 from "../assets/logos/harvard-1.jpg";
import harvard2 from "../assets/logos/harvard-2.jpg";

export interface Institution {
  id: string;
  name: string;
  city: string;
  state: string;
  level: 1 | 2 | 3;
  control: 1 | 2 | 3;
  /** lowercase search haystack */
  hay: string;
  lname: string;
}

export const LEVEL_LABEL: Record<number, string> = { 1: "4-year", 2: "2-year", 3: "Under 2-year" };
export const CONTROL_LABEL: Record<number, string> = { 1: "Public", 2: "Private nonprofit", 3: "For-profit" };

export const INSTITUTIONS: Institution[] = RAW_INSTITUTIONS.map(([id, name, city, state, level, control]) => ({
  id: String(id),
  name,
  city,
  state,
  level: level as 1 | 2 | 3,
  control: control as 1 | 2 | 3,
  lname: name.toLowerCase(),
  hay: `${name} ${city} ${state}`.toLowerCase(),
}));

export const INSTITUTION_MAP = new Map(INSTITUTIONS.map((i) => [i.id, i]));

export const STATE_NAMES: Record<string, string> = {
  AL: "Alabama", AK: "Alaska", AZ: "Arizona", AR: "Arkansas", CA: "California", CO: "Colorado",
  CT: "Connecticut", DE: "Delaware", DC: "District of Columbia", FL: "Florida", GA: "Georgia",
  HI: "Hawaii", ID: "Idaho", IL: "Illinois", IN: "Indiana", IA: "Iowa", KS: "Kansas",
  KY: "Kentucky", LA: "Louisiana", ME: "Maine", MD: "Maryland", MA: "Massachusetts",
  MI: "Michigan", MN: "Minnesota", MS: "Mississippi", MO: "Missouri", MT: "Montana",
  NE: "Nebraska", NV: "Nevada", NH: "New Hampshire", NJ: "New Jersey", NM: "New Mexico",
  NY: "New York", NC: "North Carolina", ND: "North Dakota", OH: "Ohio", OK: "Oklahoma",
  OR: "Oregon", PA: "Pennsylvania", RI: "Rhode Island", SC: "South Carolina", SD: "South Dakota",
  TN: "Tennessee", TX: "Texas", UT: "Utah", VT: "Vermont", VA: "Virginia", WA: "Washington",
  WV: "West Virginia", WI: "Wisconsin", WY: "Wyoming", AS: "American Samoa", GU: "Guam",
  MP: "Northern Mariana Islands", PR: "Puerto Rico", VI: "U.S. Virgin Islands",
  FM: "Federated States of Micronesia", MH: "Marshall Islands", PW: "Palau",
};

export const STATES = Array.from(new Set(INSTITUTIONS.map((i) => i.state)))
  .map((code) => ({ code, name: STATE_NAMES[code] ?? code }))
  .sort((a, b) => a.name.localeCompare(b.name));

/* -------------------------- AI-drawn featured crests ------------------------- */

interface Featured {
  src: string;
  blurb: string;
}

/** IPEDS unit ids → crests drawn by an image model (stylized guesses, not the official marks). */
const FEATURED: Record<string, Featured[]> = {
  "166683": [
    { src: mit1, blurb: "AI guess #1: block-letter monogram, orange on charcoal" },
    { src: mit2, blurb: "AI guess #2: navy shield with an orange circuit board" },
  ],
  "243744": [
    { src: stanford1, blurb: "AI guess #1: cardinal owl roundel with a cream ring" },
    { src: stanford2, blurb: "AI guess #2: red tree standing in a gold sunburst" },
  ],
  "166027": [
    { src: harvard1, blurb: "AI guess #1: crimson shield with a white book & stars" },
    { src: harvard2, blurb: "AI guess #2: interlocking H monogram in ivory" },
  ],
};

export const FEATURED_IDS = Object.keys(FEATURED);
export const isFeatured = (id: string) => id in FEATURED;

export interface CrestGuess {
  src: string;
  blurb: string;
  /** real = the school's actual logo · ai = drawn by an image model · generated = auto-drawn from the school's name */
  kind: "real" | "ai" | "generated";
  fit: "cover" | "contain";
  aspect: number;
  dark: boolean;
}

const GENERATED_BLURB = [
  "Auto-drawn guess: shield with a school monogram",
  "Auto-drawn guess: roundel with a campus emblem",
  "Auto-drawn guess: hex badge with a bold initial",
  "Auto-drawn guess: ceremonial seal with a ring",
];

/**
 * Logo options for a school, best first: the real logo (when we could find it), then any image-model-drawn
 * guesses, then auto-drawn guesses built from the school's name and colors.
 */
export function crestGuesses(inst: Institution, real: RealLogo | null): CrestGuess[] {
  const gen = (i: number): CrestGuess => ({
    src: crestDataUrl(inst.name, i),
    blurb: GENERATED_BLURB[i],
    kind: "generated",
    fit: "cover",
    aspect: 1,
    dark: false,
  });
  const out: CrestGuess[] = [];
  if (real) {
    out.push({
      src: real.url,
      blurb: "The school’s official logo",
      kind: "real",
      fit: "contain",
      aspect: real.aspect,
      dark: real.dark,
    });
  }
  const feat = FEATURED[inst.id];
  if (feat) {
    for (const f of feat) out.push({ src: f.src, blurb: f.blurb, kind: "ai", fit: "cover", aspect: 1, dark: false });
    out.push(gen(0), gen(3));
  } else {
    out.push(gen(0), gen(1), gen(2), gen(3));
  }
  return out;
}

/** Small image for lists: the bundled real logo if we have one, otherwise a guess. */
export function crestThumb(inst: Institution): { src: string; contain: boolean } {
  const real = bundledLogoUrl(inst.id);
  if (real) return { src: real, contain: true };
  const feat = FEATURED[inst.id];
  return { src: feat ? feat[0].src : crestDataUrl(inst.name, 0), contain: false };
}

/* --------------------------------- search -------------------------------- */

export function searchInstitutions(query: string, state: string, level: number): Institution[] {
  const tokens = query.toLowerCase().split(/\s+/).filter(Boolean);
  const q = tokens.join(" ");
  let list = INSTITUTIONS;
  if (state !== "ALL") list = list.filter((i) => i.state === state);
  if (level !== 0) list = list.filter((i) => i.level === level);
  if (tokens.length) list = list.filter((i) => tokens.every((t) => i.hay.includes(t)));

  const rank = (i: Institution) => {
    if (isFeatured(i.id)) return tokens.length && !i.lname.startsWith(q) ? 1 : -1;
    if (!tokens.length) return 3;
    if (i.lname.startsWith(q)) return 0;
    if (i.lname.includes(" " + q)) return 1;
    return 2;
  };
  // Stable sort: featured first, then best match, then (while searching) 4-year schools before
  // 2-year/other, then the dataset's alphabetical order. The unfiltered list stays purely A–Z.
  const searching = tokens.length > 0;
  return list
    .map((inst, idx) => ({ inst, idx, r: rank(inst), lv: searching ? inst.level : 0 }))
    .sort((a, b) => a.r - b.r || a.lv - b.lv || a.idx - b.idx)
    .map((x) => x.inst);
}
