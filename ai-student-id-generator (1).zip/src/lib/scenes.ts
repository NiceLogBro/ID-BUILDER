import type { SceneId } from "../types";
import granite from "../data/assets/scene-granite";
import walnut from "../data/assets/scene-walnut";
import marble from "../data/assets/scene-marble";
import slate from "../data/assets/scene-slate";

export interface Scene {
  id: Exclude<SceneId, "studio">;
  name: string;
  blurb: string;
  src: string;
  /** subtle tilt (degrees) applied to the card on this backdrop */
  tilt: number;
  credit: string;
}

/**
 * 4 simple high-contrast surface backdrops for the preview stage, so any card — light or dark —
 * pops off the background. Stored as text modules so they ship inside the app.
 */
export const SCENES: Scene[] = [
  { id: "granite", name: "Granite", blurb: "Dark speckled granite", src: granite, tilt: -1.5, credit: "Patrick" },
  { id: "walnut", name: "Walnut", blurb: "Dark walnut counter", src: walnut, tilt: -2, credit: "Karolina Grabowska" },
  { id: "marble", name: "Marble", blurb: "Bright white marble", src: marble, tilt: 1.5, credit: "ready made" },
  { id: "slate", name: "Slate", blurb: "Dark honed slate", src: slate, tilt: 0, credit: "Akbar Nemati" },
];

export function sceneById(id: SceneId): Scene | null {
  return SCENES.find((s) => s.id === id) ?? null;
}

export function randomScene(except?: SceneId): Scene {
  const pool = SCENES.filter((s) => s.id !== except);
  return pool[Math.floor(Math.random() * pool.length)] ?? SCENES[0];
}
