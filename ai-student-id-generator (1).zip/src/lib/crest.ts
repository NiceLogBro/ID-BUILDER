/**
 * Procedural "best guess" crests. Every institution gets school-style colors and a monogram
 * derived from its name (stable hash → same school always gets the same colors), in 4 emblem shapes.
 */

// [primary, secondary]
const PAIRS: [string, string][] = [
  ["#0b2a5b", "#f2b705"], // navy / gold
  ["#8c1d2c", "#f4e9d1"], // crimson / cream
  ["#0f4d36", "#e8c547"], // forest / gold
  ["#1d4ed8", "#ffffff"], // royal / white
  ["#5b1a3a", "#d3d3da"], // maroon / silver
  ["#e8590c", "#1b2a49"], // orange / navy
  ["#4b2a7b", "#f5c542"], // purple / gold
  ["#15171c", "#d4af37"], // black / gold
  ["#bb0a1e", "#aab0b6"], // scarlet / gray
  ["#0e7c86", "#ffffff"], // teal / white
  ["#7a0019", "#ffcc33"], // maroon / gold
  ["#003a70", "#d9304a"], // navy / red
  ["#2b6a3f", "#ffffff"], // green / white
  ["#a4343a", "#1d1d1f"], // brick / black
];

function hash(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

const STOP = new Set(["of", "the", "at", "and", "for", "in", "a", "an", "de", "la", "del", "&", "inc", "llc"]);

export function initialsFor(name: string): string {
  const words = name
    .replace(/[-–—/,.()&]/g, " ")
    .split(/\s+/)
    .filter(Boolean);
  const sig = words.filter((w) => !STOP.has(w.toLowerCase()));
  const base = sig.length ? sig : words;
  if (base.length === 0) return "U";
  if (base.length === 1) return Array.from(base[0]).slice(0, 2).join("").toUpperCase();
  return base
    .slice(0, 3)
    .map((w) => Array.from(w)[0])
    .join("")
    .toUpperCase();
}

const esc = (s: string) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

function starPoints(cx: number, cy: number, R: number, r: number): string {
  const pts: string[] = [];
  for (let i = 0; i < 10; i++) {
    const a = (Math.PI / 5) * i - Math.PI / 2;
    const rad = i % 2 === 0 ? R : r;
    pts.push(`${(cx + Math.cos(a) * rad).toFixed(2)},${(cy + Math.sin(a) * rad).toFixed(2)}`);
  }
  return pts.join(" ");
}

function motif(i: number, sec: string, pri: string): string {
  switch (i) {
    case 0:
      return `<polygon points="${starPoints(50, 51, 27, 11.5)}" fill="${sec}"/>`;
    case 1:
      return `<path d="M50 38C42 32 32 31 24 34V66C32 63 42 64 50 70C58 64 68 63 76 66V34C68 31 58 32 50 38Z" fill="${sec}"/><path d="M50 38V70" stroke="${pri}" stroke-width="2.2"/>`;
    case 2:
      return `<path d="M50 22C61 37 63 47 50 55C37 47 39 37 50 22Z" fill="${sec}"/><path d="M39 56H61L57 61H43Z" fill="${sec}"/><path d="M44 63H56L53 79H47Z" fill="${sec}"/>`;
    case 3:
      return `<circle cx="50" cy="40" r="15" fill="${sec}"/><circle cx="38" cy="52" r="12" fill="${sec}"/><circle cx="62" cy="52" r="12" fill="${sec}"/><rect x="46.5" y="56" width="7" height="22" rx="2" fill="${sec}"/>`;
    case 4:
      return `<path d="M35 79V44H40V36H46V44H54V36H60V44H65V79Z" fill="${sec}"/><path d="M45 79V67a5 5 0 0 1 10 0V79Z" fill="${pri}"/>`;
    default: {
      let rays = "";
      for (let k = 0; k < 8; k++) {
        const a = (Math.PI / 4) * k;
        rays += `<line x1="${(50 + Math.cos(a) * 18).toFixed(1)}" y1="${(50 + Math.sin(a) * 18).toFixed(1)}" x2="${(50 + Math.cos(a) * 28).toFixed(1)}" y2="${(50 + Math.sin(a) * 28).toFixed(1)}" stroke="${sec}" stroke-width="4" stroke-linecap="round"/>`;
      }
      return `<circle cx="50" cy="50" r="11" fill="${sec}"/>${rays}`;
    }
  }
}

const FONT = `font-family="Georgia, 'Times New Roman', serif" font-weight="700" text-anchor="middle"`;

/** The school-style color pair a generated crest uses for this name: [primary, secondary]. */
export function crestPalette(name: string): [string, string] {
  return PAIRS[hash(name) % PAIRS.length];
}

export function crestSvg(name: string, guess: number): string {
  const h = hash(name);
  const [pri, sec] = PAIRS[h % PAIRS.length];
  const ini = esc(initialsFor(name));
  const n = ini.length > 3 ? 3 : Array.from(ini).length;
  const shape = ((guess % 4) + 4) % 4;
  let body = "";

  if (shape === 0) {
    const size = n === 1 ? 42 : n === 2 ? 34 : 27;
    const by = 50 + size * 0.34;
    body =
      `<path d="M50 6L88 18V50C88 74 70 88 50 95C30 88 12 74 12 50V18Z" fill="${pri}" stroke="${sec}" stroke-width="3.5" stroke-linejoin="round"/>` +
      `<text x="50" y="${by.toFixed(1)}" font-size="${size}" fill="${sec}" ${FONT}>${ini}</text>` +
      `<rect x="35" y="${(by + 7).toFixed(1)}" width="30" height="2.6" rx="1.3" fill="${sec}"/>`;
  } else if (shape === 1) {
    body =
      `<circle cx="50" cy="50" r="46" fill="${pri}"/>` +
      `<circle cx="50" cy="50" r="39" fill="none" stroke="${sec}" stroke-width="2.5"/>` +
      motif((h >>> 4) % 6, sec, pri);
  } else if (shape === 2) {
    const hexPts = "50,5 90,27.5 90,72.5 50,95 10,72.5 10,27.5";
    const inner = "50,13 83,31.5 83,68.5 50,87 17,68.5 17,31.5";
    const letter = esc(Array.from(initialsFor(name))[0]);
    body =
      `<polygon points="${hexPts}" fill="${pri}"/>` +
      `<polygon points="${inner}" fill="none" stroke="${sec}" stroke-width="2.2"/>` +
      `<text x="50" y="62" font-size="46" fill="${sec}" ${FONT}>${letter}</text>` +
      `<rect x="34" y="70" width="32" height="3" rx="1.5" fill="${sec}"/><rect x="40" y="76" width="20" height="3" rx="1.5" fill="${sec}"/>`;
  } else {
    const size = n === 1 ? 34 : n === 2 ? 28 : 22;
    body =
      `<circle cx="50" cy="50" r="47" fill="${pri}"/>` +
      `<circle cx="50" cy="50" r="41" fill="none" stroke="${sec}" stroke-width="2" stroke-dasharray="1.5 3.6" stroke-linecap="round"/>` +
      `<circle cx="50" cy="50" r="31" fill="${sec}"/>` +
      `<text x="50" y="${(50 + size * 0.34).toFixed(1)}" font-size="${size}" fill="${pri}" ${FONT}>${ini}</text>`;
  }

  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" width="160" height="160">${body}</svg>`;
}

const urlCache = new Map<string, string>();

export function crestDataUrl(name: string, guess: number): string {
  const key = `${guess}|${name}`;
  let u = urlCache.get(key);
  if (!u) {
    u = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(crestSvg(name, guess));
    if (urlCache.size > 600) urlCache.clear();
    urlCache.set(key, u);
  }
  return u;
}
